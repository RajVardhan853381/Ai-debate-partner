import { CreateBuyerSchema, CsvBuyerSchema } from '../../src/lib/validations/buyer';

describe('Buyer Validation', () => {
  describe('CreateBuyerSchema', () => {
    const validBuyer = {
      fullName: 'John Doe',
      email: 'john@example.com',
      phone: '9876543210',
      city: 'Chandigarh' as const,
      propertyType: 'Apartment' as const,
      bhk: '3' as const,
      purpose: 'Buy' as const,
      timeline: '3-6m' as const,
      source: 'Website' as const,
      status: 'New' as const,
      notes: 'Looking for a nice apartment',
      tags: ['urgent'],
    };

    test('should validate correct buyer data', () => {
      const result = CreateBuyerSchema.safeParse(validBuyer);
      expect(result.success).toBe(true);
    });

    test('should require fullName with minimum length', () => {
      const result = CreateBuyerSchema.safeParse({
        ...validBuyer,
        fullName: 'A',
      });
      expect(result.success).toBe(false);
      expect(result.error?.issues?.find(issue => issue.path.includes('fullName'))?.message).toContain('at least 2 characters');
    });

    test('should validate phone number format', () => {
      const result = CreateBuyerSchema.safeParse({
        ...validBuyer,
        phone: '123',
      });
      expect(result.success).toBe(false);
      expect(result.error?.issues?.find(issue => issue.path.includes('phone'))?.message).toContain('10-15 digits');
    });

    test('should require BHK for Apartment properties', () => {
      const result = CreateBuyerSchema.safeParse({
        ...validBuyer,
        propertyType: 'Apartment' as const,
        bhk: undefined,
      });
      expect(result.success).toBe(false);
      expect(result.error?.issues?.[0].message).toContain('BHK is required');
    });

    test('should allow empty BHK for Plot properties', () => {
      const result = CreateBuyerSchema.safeParse({
        ...validBuyer,
        propertyType: 'Plot' as const,
        bhk: undefined,
      });
      expect(result.success).toBe(true);
    });

    test('should validate budget range', () => {
      const result = CreateBuyerSchema.safeParse({
        ...validBuyer,
        budgetMin: 100000,
        budgetMax: 50000,
      });
      expect(result.success).toBe(false);
      expect(result.error?.issues?.[0].message).toContain('greater than or equal to budget minimum');
    });

    test('should allow valid budget range', () => {
      const result = CreateBuyerSchema.safeParse({
        ...validBuyer,
        budgetMin: 50000,
        budgetMax: 100000,
      });
      expect(result.success).toBe(true);
    });

    test('should handle empty email', () => {
      const result = CreateBuyerSchema.safeParse({
        ...validBuyer,
        email: '',
      });
      expect(result.success).toBe(true);
    });

    test('should validate notes length', () => {
      const longNotes = 'a'.repeat(1001);
      const result = CreateBuyerSchema.safeParse({
        ...validBuyer,
        notes: longNotes,
      });
      expect(result.success).toBe(false);
      expect(result.error?.issues?.find(issue => issue.path.includes('notes'))?.message).toContain('at most 1000 characters');
    });
  });

  describe('CsvBuyerSchema', () => {
    const validCsvBuyer = {
      fullName: 'John Doe',
      email: 'john@example.com',
      phone: '9876543210',
      city: 'Chandigarh' as const,
      propertyType: 'Apartment' as const,
      bhk: '3' as const,
      purpose: 'Buy' as const,
      budgetMin: '5000000',
      budgetMax: '8000000',
      timeline: '3-6m' as const,
      source: 'Website' as const,
      notes: 'Looking for apartment',
      tags: 'urgent,premium',
      status: 'New' as const,
    };

    test('should validate correct CSV buyer data', () => {
      const result = CsvBuyerSchema.safeParse(validCsvBuyer);
      expect(result.success).toBe(true);
      if (result.success) {
        expect(result.data.tags).toEqual(['urgent', 'premium']);
        expect(result.data.budgetMin).toBe(5000000);
        expect(result.data.budgetMax).toBe(8000000);
      }
    });

    test('should handle empty budget fields', () => {
      const result = CsvBuyerSchema.safeParse({
        ...validCsvBuyer,
        budgetMin: '',
        budgetMax: '',
      });
      expect(result.success).toBe(true);
      if (result.success) {
        expect(result.data.budgetMin).toBeUndefined();
        expect(result.data.budgetMax).toBeUndefined();
      }
    });

    test('should parse tags correctly', () => {
      const result = CsvBuyerSchema.safeParse({
        ...validCsvBuyer,
        tags: 'urgent, premium, family friendly',
      });
      expect(result.success).toBe(true);
      if (result.success) {
        expect(result.data.tags).toEqual(['urgent', 'premium', 'family friendly']);
      }
    });

    test('should handle empty tags', () => {
      const result = CsvBuyerSchema.safeParse({
        ...validCsvBuyer,
        tags: '',
      });
      expect(result.success).toBe(true);
      if (result.success) {
        expect(result.data.tags).toEqual([]);
      }
    });
  });
});
