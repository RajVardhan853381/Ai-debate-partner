// src/app/buyers/import/page.tsx
'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

interface ImportResult {
  totalRows: number;
  validRows: number;
  created: number;
  errors: { row: number; error: string }[];
}

export default function ImportBuyersPage() {
  const router = useRouter();
  const [file, setFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [result, setResult] = useState<ImportResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      setResult(null);
      setError(null);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!file) {
      setError('Please select a CSV file');
      return;
    }

    setIsUploading(true);
    setError(null);

    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch('/api/buyers/import', {
        method: 'POST',
        body: formData,
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Import failed');
      }

      setResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Import failed');
    } finally {
      setIsUploading(false);
    }
  };

  const downloadTemplate = () => {
    const csvContent = `fullName,email,phone,city,propertyType,bhk,purpose,budgetMin,budgetMax,timeline,source,notes,tags,status
John Doe,john@example.com,9876543210,Chandigarh,Apartment,3,Buy,5000000,8000000,3-6m,Website,Looking for 3BHK apartment,"urgent,premium",New
Jane Smith,jane@example.com,9876543211,Mohali,Villa,4,Rent,40000,60000,0-3m,Referral,Needs pet-friendly villa,"pets,garden",Qualified`;

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.style.display = 'none';
    a.href = url;
    a.download = 'buyers-import-template.csv';
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
  };

  return (
    <div className="container mx-auto py-8">
      <div className="max-w-2xl mx-auto">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900">Import Buyers from CSV</h1>
          <p className="text-gray-600 mt-2">Upload a CSV file to import multiple buyer leads</p>
        </div>

        {/* Instructions */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-6">
          <h2 className="text-lg font-semibold text-blue-900 mb-3">Import Instructions</h2>
          <div className="space-y-2 text-sm text-blue-800">
            <p>• Maximum 200 rows per import</p>
            <p>• File size limit: 5MB</p>
            <p>• Required columns: fullName, phone, city, propertyType, purpose, timeline, source</p>
            <p>• BHK is required for Apartment and Villa properties</p>
            <p>• budgetMax must be greater than or equal to budgetMin when both are provided</p>
            <p>• Tags should be comma-separated in a single cell</p>
          </div>
          <div className="mt-4">
            <button
              onClick={downloadTemplate}
              className="text-blue-600 hover:text-blue-800 font-medium"
            >
              Download Template CSV →
            </button>
          </div>
        </div>

        {/* CSV Format Reference */}
        <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 mb-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-3">CSV Format</h2>
          <div className="text-sm text-gray-700 space-y-1">
            <p><strong>Required Headers:</strong></p>
            <code className="block bg-white p-2 rounded text-xs overflow-x-auto">
              fullName,email,phone,city,propertyType,bhk,purpose,budgetMin,budgetMax,timeline,source,notes,tags,status
            </code>
            
            <p className="mt-3"><strong>Enum Values:</strong></p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
              <div>
                <strong>city:</strong> Chandigarh, Mohali, Zirakpur, Panchkula, Other
              </div>
              <div>
                <strong>propertyType:</strong> Apartment, Villa, Plot, Office, Retail
              </div>
              <div>
                <strong>bhk:</strong> Studio, 1, 2, 3, 4
              </div>
              <div>
                <strong>purpose:</strong> Buy, Rent
              </div>
              <div>
                <strong>timeline:</strong> 0-3m, 3-6m, >6m, Exploring
              </div>
              <div>
                <strong>source:</strong> Website, Referral, Walk-in, Call, Other
              </div>
              <div>
                <strong>status:</strong> New, Qualified, Contacted, Visited, Negotiation, Converted, Dropped
              </div>
            </div>
          </div>
        </div>

        {/* Upload Form */}
        <div className="bg-white p-6 rounded-lg border mb-6">
          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <label htmlFor="csvFile" className="block text-sm font-medium text-gray-700 mb-2">
                Select CSV File
              </label>
              <input
                type="file"
                id="csvFile"
                accept=".csv"
                onChange={handleFileChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                disabled={isUploading}
              />
            </div>

            {file && (
              <div className="mb-4 p-3 bg-gray-50 rounded">
                <p className="text-sm text-gray-700">
                  <strong>Selected file:</strong> {file.name} ({(file.size / 1024).toFixed(1)} KB)
                </p>
              </div>
            )}

            <div className="flex justify-between">
              <Link
                href="/buyers"
                className="px-4 py-2 text-gray-700 bg-gray-200 rounded-md hover:bg-gray-300"
              >
                Cancel
              </Link>
              <button
                type="submit"
                disabled={!file || isUploading}
                className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isUploading ? 'Importing...' : 'Import CSV'}
              </button>
            </div>
          </form>
        </div>

        {/* Error Display */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
            <div className="flex">
              <div className="text-red-400">
                <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                </svg>
              </div>
              <div className="ml-3">
                <h3 className="text-sm font-medium text-red-800">Import Error</h3>
                <div className="mt-2 text-sm text-red-700">{error}</div>
              </div>
            </div>
          </div>
        )}

        {/* Results Display */}
        {result && (
          <div className="bg-white rounded-lg border overflow-hidden">
            <div className="p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Import Results</h2>
              
              {/* Summary */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">{result.totalRows}</div>
                  <div className="text-sm text-blue-800">Total Rows</div>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">{result.validRows}</div>
                  <div className="text-sm text-green-800">Valid Rows</div>
                </div>
                <div className="text-center p-4 bg-emerald-50 rounded-lg">
                  <div className="text-2xl font-bold text-emerald-600">{result.created}</div>
                  <div className="text-sm text-emerald-800">Created</div>
                </div>
                <div className="text-center p-4 bg-red-50 rounded-