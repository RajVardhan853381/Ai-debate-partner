// src/app/api/buyers/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { BuyerService } from '@/lib/services/buyerService';
import { CreateBuyerSchema, BuyerFiltersSchema } from '@/lib/validations/buyer';
import { rateLimit } from '@/lib/utils/rateLimit';

// GET /api/buyers - List buyers with filters
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const filters = BuyerFiltersSchema.parse({
      search: searchParams.get('search') || undefined,
      city: searchParams.get('city') || undefined,
      propertyType: searchParams.get('propertyType') || undefined,
      status: searchParams.get('status') || undefined,
      timeline: searchParams.get('timeline') || undefined,
      page: searchParams.get('page') ? parseInt(searchParams.get('page')!) : 1,
      sort: searchParams.get('sort') || 'updatedAt',
      order: searchParams.get('order') || 'desc',
    });

    const result = await BuyerService.list(filters, session.user.id);
    return NextResponse.json(result);
  } catch (error) {
    console.error('GET /api/buyers error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// POST /api/buyers - Create new buyer
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Rate limiting
    const rateLimitResult = await rateLimit(
      `create_buyer_${session.user.id}`,
      10, // 10 requests
      60 * 1000 // per minute
    );

    if (!rateLimitResult.success) {
      return NextResponse.json(
        { error: 'Rate limit exceeded' },
        { status: 429 }
      );
    }

    const body = await request.json();
    const validatedData = CreateBuyerSchema.parse(body);

    const buyer = await BuyerService.create(validatedData, session.user.id);
    return NextResponse.json(buyer, { status: 201 });
  } catch (error) {
    console.error('POST /api/buyers error:', error);
    
    if (error instanceof Error && error.name === 'ZodError') {
      return NextResponse.json(
        { error: 'Invalid data', details: error },
        { status: 400 }
      );
    }

    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// src/app/api/buyers/[id]/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { BuyerService } from '@/lib/services/buyerService';
import { UpdateBuyerSchema } from '@/lib/validations/buyer';
import { rateLimit } from '@/lib/utils/rateLimit';

interface RouteParams {
  params: { id: string };
}

// GET /api/buyers/[id] - Get single buyer
export async function GET(request: NextRequest, { params }: RouteParams) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const buyer = await BuyerService.getById(params.id, session.user.id);
    if (!buyer) {
      return NextResponse.json({ error: 'Buyer not found' }, { status: 404 });
    }

    return NextResponse.json(buyer);
  } catch (error) {
    console.error(`GET /api/buyers/${params.id} error:`, error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// PUT /api/buyers/[id] - Update buyer
export async function PUT(request: NextRequest, { params }: RouteParams) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Rate limiting
    const rateLimitResult = await rateLimit(
      `update_buyer_${session.user.id}`,
      20, // 20 requests
      60 * 1000 // per minute
    );

    if (!rateLimitResult.success) {
      return NextResponse.json(
        { error: 'Rate limit exceeded' },
        { status: 429 }
      );
    }

    const body = await request.json();
    const validatedData = UpdateBuyerSchema.parse({ ...body, id: params.id });

    const result = await BuyerService.update(params.id, validatedData, session.user.id);
    
    if (result.error) {
      return NextResponse.json(
        { error: result.error },
        { status: result.error.includes('modified') ? 409 : 404 }
      );
    }

    return NextResponse.json(result.buyer);
  } catch (error) {
    console.error(`PUT /api/buyers/${params.id} error:`, error);
    
    if (error instanceof Error && error.name === 'ZodError') {
      return NextResponse.json(
        { error: 'Invalid data', details: error },
        { status: 400 }
      );
    }

    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// DELETE /api/buyers/[id] - Delete buyer
export async function DELETE(request: NextRequest, { params }: RouteParams) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const success = await BuyerService.delete(params.id, session.user.id);
    if (!success) {
      return NextResponse.json({ error: 'Buyer not found' }, { status: 404 });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error(`DELETE /api/buyers/${params.id} error:`, error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// src/app/api/buyers/import/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { BuyerService } from '@/lib/services/buyerService';
import { CsvBuyerSchema } from '@/lib/validations/buyer';
import Papa from 'papaparse';
import { rateLimit } from '@/lib/utils/rateLimit';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Rate limiting for imports
    const rateLimitResult = await rateLimit(
      `import_buyers_${session.user.id}`,
      2, // 2 imports
      5 * 60 * 1000 // per 5 minutes
    );

    if (!rateLimitResult.success) {
      return NextResponse.json(
        { error: 'Import rate limit exceeded. Please wait before importing again.' },
        { status: 429 }
      );
    }

    const formData = await request.formData();
    const file = formData.get('file') as File;
    
    if (!file) {
      return NextResponse.json({ error: 'No file uploaded' }, { status: 400 });
    }

    if (!file.name.endsWith('.csv')) {
      return NextResponse.json({ error: 'File must be a CSV' }, { status: 400 });
    }

    if (file.size > 5 * 1024 * 1024) { // 5MB limit
      return NextResponse.json({ error: 'File too large' }, { status: 400 });
    }

    const csvText = await file.text();
    
    // Parse CSV
    const parseResult = Papa.parse(csvText, {
      header: true,
      skipEmptyLines: true,
      dynamicTyping: false,
      delimitersToGuess: [',', '\t', '|', ';']
    });

    if (parseResult.errors.length > 0) {
      return NextResponse.json({
        error: 'CSV parsing failed',
        details: parseResult.errors
      }, { status: 400 });
    }

    const rows = parseResult.data as any[];
    
    if (rows.length === 0) {
      return NextResponse.json({ error: 'CSV file is empty' }, { status: 400 });
    }

    if (rows.length > 200) {
      return NextResponse.json({ 
        error: 'CSV file has too many rows. Maximum 200 rows allowed.' 
      }, { status: 400 });
    }

    // Validate and process each row
    const validRows = [];
    const errors: { row: number; error: string }[] = [];

    for (let i = 0; i < rows.length; i++) {
      try {
        const validatedRow = CsvBuyerSchema.parse(rows[i]);
        validRows.push(validatedRow);
      } catch (error) {
        errors.push({
          row: i + 1,
          error: error instanceof Error ? error.message : 'Invalid data'
        });
      }
    }

    // Import valid rows
    let importResult = { created: 0, errors: [] };
    
    if (validRows.length > 0) {
      importResult = await BuyerService.bulkCreate(validRows, session.user.id);
    }

    // Combine validation and import errors
    const allErrors = [...errors, ...importResult.errors];

    return NextResponse.json({
      success: true,
      totalRows: rows.length,
      validRows: validRows.length,
      created: importResult.created,
      errors: allErrors
    });

  } catch (error) {
    console.error('POST /api/buyers/import error:', error);
    return NextResponse.json(
      { error: 'Import failed' },
      { status: 500 }
    );
  }
}

// src/app/api/buyers/export/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { BuyerService } from '@/lib/services/buyerService';
import { BuyerFiltersSchema } from '@/lib/validations/buyer';
import Papa from 'papaparse';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const filters = BuyerFiltersSchema.parse({
      search: searchParams.get('search') || undefined,
      city: searchParams.get('city') || undefined,
      propertyType: searchParams.get('propertyType') || undefined,
      status: searchParams.get('status') || undefined,
      timeline: searchParams.get('timeline') || undefined,
      page: 1, // Export ignores pagination
      sort: searchParams.get('sort') || 'updatedAt',
      order: searchParams.get('order') || 'desc',
    });

    const csvData = await BuyerService.exportCsv(filters, session.user.id);
    
    const csv = Papa.unparse(csvData, {
      header: true,
    });

    return new NextResponse(csv, {
      status: 200,
      headers: {
        'Content-Type': 'text/csv',
        'Content-Disposition': `attachment; filename="buyers-${new Date().toISOString().split('T')[0]}.csv"`,
      },
    });

  } catch (error) {
    console.error('GET /api/buyers/export error:', error);
    return NextResponse.json(
      { error: 'Export failed' },
      { status: 500 }
    );
  }
}

// src/lib/utils/rateLimit.ts
interface RateLimitStore {
  [key: string]: {
    count: number;
    resetTime: number;
  };
}

const store: RateLimitStore = {};

export async function rate