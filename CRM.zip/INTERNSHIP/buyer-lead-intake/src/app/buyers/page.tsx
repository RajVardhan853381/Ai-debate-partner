'use client';

import { Suspense } from 'react';
import Link from 'next/link';
import { BuyerFiltersSchema, BuyerFilters } from '@/lib/validations/buyer';
import { BuyersFilters } from '@/components/BuyersFilters';
import { BuyersList } from '@/components/BuyersList';
import { Buyer } from '@/lib/db/schema';

interface PageProps {
  searchParams: Record<string, string | string[] | undefined>;
}

export default function BuyersPage({ searchParams }: PageProps) {
  // Parse and validate search params
  const filters: BuyerFilters = BuyerFiltersSchema.parse({
    search: searchParams.search || undefined,
    city: searchParams.city || undefined,
    propertyType: searchParams.propertyType || undefined,
    status: searchParams.status || undefined,
    timeline: searchParams.timeline || undefined,
    page: searchParams.page ? parseInt(searchParams.page as string) : 1,
    sort: searchParams.sort || 'updatedAt',
    order: searchParams.order || 'desc',
  });

  // Placeholder empty data for now
  const buyers: Buyer[] = [];
  const pagination = { page: 1, pageSize: 10, totalCount: 0, totalPages: 0 };

  return (
    <div className="container mx-auto py-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Buyer Leads</h1>
          <p className="text-gray-600 mt-1">Manage and track your buyer leads</p>
        </div>
        <div className="flex gap-3">
          <Link
            href="/buyers/import"
            className="px-4 py-2 text-blue-600 bg-blue-50 border border-blue-200 rounded-md hover:bg-blue-100"
          >
            Import CSV
          </Link>
          <Link
            href="/buyers/new"
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
          >
            Add New Lead
          </Link>
        </div>
      </div>

      <Suspense fallback={<div>Loading filters...</div>}>
        <BuyersFilters initialFilters={filters} />
      </Suspense>

      <Suspense fallback={<div>Loading buyers...</div>}>
        <BuyersList buyers={buyers} pagination={pagination} />
      </Suspense>
    </div>
  );
}
