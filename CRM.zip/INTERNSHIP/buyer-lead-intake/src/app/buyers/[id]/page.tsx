// src/app/buyers/[id]/page.tsx
import { getServerSession } from 'next-auth';
import { notFound } from 'next/navigation';
import { authOptions } from '@/lib/auth';
import { BuyerService } from '@/lib/services/buyerService';
import { BuyerDetail } from '@/components/BuyerDetail';

interface PageProps {
  params: { id: string };
}

export default async function BuyerDetailPage({ params }: PageProps) {
  const session = await getServerSession(authOptions);
  
  if (!session?.user) {
    return <div>Please sign in to view this buyer.</div>;
  }

  const buyer = await BuyerService.getById(params.id, session.user.id);
  
  if (!buyer) {
    notFound();
  }

  const history = await BuyerService.getHistory(params.id);

  return <BuyerDetail buyer={buyer} history={history} />;
}

// src/app/buyers/[id]/edit/page.tsx
'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { BuyerForm } from '@/components/BuyerForm';
import { UpdateBuyerInput } from '@/lib/validations/buyer';
import { Buyer } from '@/lib/db';

interface PageProps {
  params: { id: string };
}

export default function EditBuyerPage({ params }: PageProps) {
  const router = useRouter();
  const [buyer, setBuyer] = useState<Buyer | null>(null);
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchBuyer();
  }, [params.id]);

  const fetchBuyer = async () => {
    try {
      const response = await fetch(`/api/buyers/${params.id}`);
      if (response.ok) {
        const data = await response.json();
        setBuyer(data);
      } else if (response.status === 404) {
        router.push('/buyers');
      } else {
        setError('Failed to load buyer details');
      }
    } catch (err) {
      setError('Failed to load buyer details');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (data: UpdateBuyerInput) => {
    if (!buyer) return;

    setIsSubmitting(true);
    setError(null);

    try {
      const response = await fetch(`/api/buyers/${params.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...data,
          updatedAt: buyer.updatedAt.toISOString(),
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        
        if (response.status === 409) {
          // Concurrency conflict
          setError(errorData.error);
          // Refresh buyer data
          await fetchBuyer();
          return;
        }
        
        throw new Error(errorData.error || 'Failed to update buyer');
      }

      router.push(`/buyers/${params.id}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto py-8">
        <div className="max-w-2xl mx-auto">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded mb-4"></div>
            <div className="space-y-4">
              <div className="h-4 bg-gray-200 rounded w-3/4"></div>
              <div className="h-4 bg-gray-200 rounded w-1/2"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!buyer) {
    return (
      <div className="container mx-auto py-8">
        <div className="max-w-2xl mx-auto text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Buyer Not Found</h1>
          <p className="text-gray-600">The buyer you're looking for doesn't exist or you don't have permission to edit it.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8">
      <div className="max-w-2xl mx-auto">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900">Edit Lead</h1>
          <p className="text-gray-600 mt-2">Update buyer information</p>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-md">
            <div className="text-red-700">{error}</div>
          </div>
        )}

        <BuyerForm
          initialData={buyer}
          onSubmit={handleSubmit}
          isSubmitting={isSubmitting}
          submitButtonText="Update Lead"
          isUpdate={true}
        />
      </div>
    </div>
  );
}

// src/components/BuyerDetail.tsx
'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Buyer, BuyerHistory } from '@/lib/db';

interface BuyerDetailProps {
  buyer: Buyer;
  history: BuyerHistory[];
}

export function BuyerDetail({ buyer, history }: BuyerDetailProps) {
  const router = useRouter();
  const [isDeleting, setIsDeleting] = useState(false);

  const formatCurrency = (amount?: number | null) => {
    if (!amount) return 'Not specified';
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatBudgetRange = (min?: number | null, max?: number | null) => {
    if (!min && !max) return 'Not specified';
    if (!min) return `Up to ${formatCurrency(max)}`;
    if (!max) return `From ${formatCurrency(min)}`;
    return `${formatCurrency(min)} - ${formatCurrency(max)}`;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'New': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Qualified': return 'bg-green-100 text-green-800 border-green-200';
      case 'Contacted': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'Visited': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'Negotiation': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'Converted': return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'Dropped': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const handleDelete = async () => {
    if (!confirm('Are you sure you want to delete this buyer? This action cannot be undone.')) {
      return;
    }

    setIsDeleting(true);

    try {
      const response = await fetch(`/api/buyers/${buyer.id}`, {
        method: 'DELETE',
      });

      if (!response.ok) {
        throw new Error('Failed to delete buyer');
      }

      router.push('/buyers');
    } catch (error) {
      alert('Failed to delete buyer. Please try again.');
      setIsDeleting(false);
    }
  };

  const formatHistoryValue = (value: any): string => {
    if (value === null || value === undefined) return 'None';
    if (Array.isArray(value)) return value.join(', ');
    if (typeof value === 'object') return JSON.stringify(value);
    return String(value);
  };

  return (
    <div className="container mx-auto py-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-start mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">{buyer.fullName}</h1>
            <p className="text-gray-600 mt-1">Lead Details</p>
          </div>
          <div className="flex gap-3">
            <Link
              href={`/buyers/${buyer.id}/edit`}
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            >
              Edit
            </Link>
            <button
              onClick={handleDelete}
              disabled={isDeleting}
              className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isDeleting ? 'Deleting...' : 'Delete'}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Details */}
          <div className="lg:col-span-2 space-y-6">
            {/* Personal Information */}
            <div className="bg-white p-6 rounded-lg border">
              <h2 className="text-lg font-semibold mb-4">Personal Information</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-500">Full Name</label>
                  <p className="text-gray-900">{buyer.fullName}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Phone</label>
                  <p className="text-gray-900">
                    <a href={`tel:${buyer.phone}`} className="text-blue-600 hover:underline">
                      {buyer.phone}
                    </a>
                  </p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Email</label>
                  <p className="text-gray-900">
                    {buyer.email ? (
                      <a href={`mailto:${buyer.email}`} className="text-blue-600 hover:underline">
                        {buyer.email}
                      </a>
                    ) : (
                      'Not provided'
                    )}
                  </p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">City</label>
                  <p className="text-gray-900">{buyer.city}</p>
                </div>
              </div>
            </div>

            {/* Property Requirements */}
            <div className="bg-white p-6 rounded-lg border">
              <h2 className="text-lg font-semibold mb-4">Property Requirements</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-500">Property Type</label>
                  <p className="text-gray-900">{buyer.propertyType}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">BHK</label>
                  <p className="text-gray-900">{buyer.bhk || 'Not applicable'}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Purpose</label>
                  <p className="text-gray-900">{buyer.purpose}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Timeline</label>
                  <p className="text-gray-900">{buyer.timeline}</p>
                </div>
                <div className="md:col-span-2">
                  <label className="text-sm font-medium text-gray-500">Budget Range</label>
                  <p className="text-gray-900">{formatBudgetRange(buyer.budgetMin, buyer.budgetMax)}</p>
                </div>
              </div>
            </div>

            {/* Additional Information */}
            <div className="bg-white p-6 rounded-lg border">
              <h2 className="text-lg font-semibold mb-4">Additional Information</h2>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-gray-500">Lead Source</label>
                  <p className="text-gray-900">{buyer.source}</p>
                </div>
                
                {buyer.tags && buyer.tags.length > 0 && (
                  <div>
                    <label className="text-sm font-medium text-gray-500">Tags</label>
                    <div className="flex flex-wrap gap-2 mt-1">
                      {buyer.tags.map(tag => (
                        <span
                          key={tag}
                          className="inline-flex px-2 py-1 rounded-full text-sm bg-blue-100 text-blue-800"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {buyer.notes && (
                  <div>
                    <label className="text-sm font-medium text-gray-500">Notes</label>
                    <p className="text-gray-900 whitespace-pre-wrap">{buyer.notes}</p>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-gray-500">Created</label>
                    <p className="text-gray-900">{new Date(buyer.createdAt).toLocaleString()}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-500">Last Updated</label>
                    <p className="text-gray-900">{new Date(buyer.updatedAt).toLocaleString()}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Status */}
            <div className="bg-white p-6 rounded-lg border">
              <h3 className="text-lg font-semibold mb-3">Current Status</h3>
              <div className={`inline-flex px-3 py-2 rounded-full text-sm font-medium border ${getStatusColor(buyer.status)}`}>
                {buyer.status}
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-white p-6 rounded-lg border">
              <h3 className="text-lg font-semibold mb-3">Quick Actions</h3>
              <div className="space-y-2">
                {buyer.phone && (
                  <a
                    href={`tel:${buyer.phone}`}
                    className="block w-full px-4 py-2 text-center text-green-600 bg-green-50 border border-green-200 rounded-md hover:bg-green-100"
                  >
                    Call {buyer.phone}
                  </a>
                )}
                {buyer.email && (
                  <a
                    href={`mailto:${buyer.email}`}
                    className="block w-full px-4 py-2 text-center text-blue-600 bg-blue-50 border border-blue-200 rounded-md hover:bg-blue-100"
                  >
                    Email {buyer.email}
                  </a>
                )}
              </div>
            </div>

            {/* Recent Activity */}
            {history.length > 0 && (
              <div className="bg-white p-6 rounded-lg border">
                <h3 className="text-lg font-semibold mb-3">Recent Activity</h3>
                <div className="space-y-3">
                  {history.map((entry) => (
                    <div key={entry.id} className="text-sm">
                      <div className="text-gray-500">
                        {new Date(entry.changedAt).toLocaleDateString()}
                      </div>
                      <div className="space-y-1">
                        {Object.entries(entry.diff).map(([field, change]) => (
                          <div key={field} className="text-gray-700">
                            <span className="font-medium">{field}:</span>{' '}
                            {change.old !== null && (
                              <>
                                <span className="text-red-600">
                                  {formatHistoryValue(change.old)}
                                </span>
                                {' → '}
                              </>
                            )}
                            <span className="text-green-600">
                              {formatHistoryValue(change.new)}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}