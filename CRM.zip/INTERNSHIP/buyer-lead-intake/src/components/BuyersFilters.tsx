import { useState, useEffect, useCallback } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { BuyerFilters } from '@/lib/validations/buyer';

interface BuyersFiltersProps {
  initialFilters: BuyerFilters;
}

export function BuyersFilters({ initialFilters }: BuyersFiltersProps) {
  const router = useRouter();
  const searchParams = useSearchParams();

  const [search, setSearch] = useState(initialFilters.search || '');
  const [city, setCity] = useState(initialFilters.city || '');
  const [propertyType, setPropertyType] = useState(initialFilters.propertyType || '');
  const [status, setStatus] = useState(initialFilters.status || '');
  const [timeline, setTimeline] = useState(initialFilters.timeline || '');
  const [sort, setSort] = useState(initialFilters.sort || 'updatedAt');
  const [order, setOrder] = useState<'asc' | 'desc'>(initialFilters.order || 'desc');

  const updateUrl = useCallback(() => {
    const params = new URLSearchParams();

    if (search) params.set('search', search);
    if (city) params.set('city', city);
    if (propertyType) params.set('propertyType', propertyType);
    if (status) params.set('status', status);
    if (timeline) params.set('timeline', timeline);
    if (sort !== 'updatedAt') params.set('sort', sort);
    if (order !== 'desc') params.set('order', order);

    // Reset to page 1 when filters change
    const currentPage = searchParams.get('page');
    if (currentPage && currentPage !== '1') {
      params.set('page', '1');
    }

    const queryString = params.toString();
    const newUrl = queryString ? `/buyers?${queryString}` : '/buyers';

    router.push(newUrl);
  }, [search, city, propertyType, status, timeline, sort, order, router, searchParams]);

  // Debounced search
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      updateUrl();
    }, 500);

    return () => clearTimeout(timeoutId);
  }, [search, updateUrl]);

  // Update URL when filters change
  useEffect(() => {
    updateUrl();
  }, [updateUrl]);

  const clearFilters = () => {
    setSearch('');
    setCity('');
    setPropertyType('');
    setStatus('');
    setTimeline('');
    setSort('updatedAt');
    setOrder('desc');
    router.push('/buyers');
  };

  const exportCsv = async () => {
    try {
      const params = new URLSearchParams();
      if (search) params.set('search', search);
      if (city) params.set('city', city);
      if (propertyType) params.set('propertyType', propertyType);
      if (status) params.set('status', status);
      if (timeline) params.set('timeline', timeline);
      params.set('sort', sort);
      params.set('order', order);

      const response = await fetch(`/api/buyers/export?${params}`);
      if (!response.ok) throw new Error('Export failed');

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.style.display = 'none';
      a.href = url;
      a.download = `buyers-${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Export failed:', error);
      alert('Export failed. Please try again.');
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg border mb-6">
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-4">
        <div className="lg:col-span-2">
          <label htmlFor="search" className="block text-sm font-medium text-gray-700 mb-1">
            Search
          </label>
          <input
            type="text"
            id="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by name, phone, or email..."
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div>
          <label htmlFor="city" className="block text-sm font-medium text-gray-700 mb-1">
            City
          </label>
          <select
            id="city"
            value={city}
            onChange={(e) => setCity(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="">All Cities</option>
            <option value="Chandigarh">Chandigarh</option>
            <option value="Mohali">Mohali</option>
            <option value="Zirakpur">Zirakpur</option>
            <option value="Panchkula">Panchkula</option>
            <option value="Other">Other</option>
          </select>
        </div>

        <div>
          <label htmlFor="propertyType" className="block text-sm font-medium text-gray-700 mb-1">
            Property Type
          </label>
          <select
            id="propertyType"
            value={propertyType}
            onChange={(e) => setPropertyType(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="">All Types</option>
            <option value="Apartment">Apartment</option>
            <option value="Villa">Villa</option>
            <option value="Plot">Plot</option>
            <option value="Office">Office</option>
            <option value="Retail">Retail</option>
          </select>
        </div>

        <div>
          <label htmlFor="status" className="block text-sm font-medium text-gray-700 mb-1">
            Status
          </label>
          <select
            id="status"
            value={status}
            onChange={(e) => setStatus(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="">All Status</option>
            <option value="New">New</option>
            <option value="Qualified">Qualified</option>
            <option value="Contacted">Contacted</option>
            <option value="Visited">Visited</option>
            <option value="Negotiation">Negotiation</option>
            <option value="Converted">Converted</option>
            <option value="Dropped">Dropped</option>
          </select>
        </div>

        <div>
          <label htmlFor="timeline" className="block text-sm font-medium text-gray-700 mb-1">
            Timeline
          </label>
          <select
            id="timeline"
            value={timeline}
            onChange={(e) => setTimeline(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="">All Timelines</option>
            <option value="0-3m">0-3 months</option>
            <option value="3-6m">3-6 months</option>
            <option value=">6m">More than 6 months</option>
            <option value="Exploring">Exploring</option>
          </select>
        </div>
      </div>

      <div className="flex flex-wrap gap-4 items-center justify-between">
        <div className="flex gap-4">
          <div>
            <label htmlFor="sort" className="block text-sm font-medium text-gray-700 mb-1">
              Sort by
            </label>
            <select
              id="sort"
              value={sort}
              onChange={(e) => setSort(e.target.value as 'updatedAt' | 'fullName' | 'createdAt')}
              className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="updatedAt">Last Updated</option>
              <option value="fullName">Name</option>
              <option value="createdAt">Created Date</option>
            </select>
          </div>

          <div>
            <label htmlFor="order" className="block text-sm font-medium text-gray-700 mb-1">
              Order
            </label>
            <select
              id="order"
              value={order}
            onChange={(e) => setOrder(e.target.value as 'asc' | 'desc')}
              className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="desc">Descending</option>
              <option value="asc">Ascending</option>
            </select>
          </div>
        </div>

        <div className="flex gap-2">
          <button
            onClick={clearFilters}
            className="px-4 py-2 text-gray-700 bg-gray-100 border border-gray-300 rounded-md hover:bg-gray-200"
          >
            Clear Filters
          </button>
          <button
            onClick={exportCsv}
            className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
          >
            Export CSV
          </button>
        </div>
      </div>
    </div>
  );
}
