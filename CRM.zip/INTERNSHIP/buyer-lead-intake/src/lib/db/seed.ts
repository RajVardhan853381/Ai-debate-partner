import { db } from './index';
import { users, buyers } from './schema';
import { randomUUID } from 'crypto';

async function seed() {
  try {
    console.log('Seeding database...');

    // Create a demo user
    const userId = randomUUID();
    await db.insert(users).values({
      id: userId,
      email: 'demo@example.com',
      name: 'Demo User',
      createdAt: new Date(),
    });

    console.log('Created user:', userId);

    // Create sample buyers
    const sampleBuyers = [
      {
        id: randomUUID(),
        fullName: 'John Doe',
        email: 'john@example.com',
        phone: '9876543210',
        city: 'Chandigarh',
        propertyType: 'Apartment',
        bhk: '3',
        purpose: 'Buy',
        budgetMin: 5000000,
        budgetMax: 8000000,
        timeline: '3-6m',
        source: 'Website',
        status: 'New',
        notes: 'Looking for a 3BHK apartment in Sector 17',
        tags: JSON.stringify(['urgent', 'premium']),
        ownerId: userId,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: randomUUID(),
        fullName: 'Jane Smith',
        email: 'jane@example.com',
        phone: '9876543211',
        city: 'Mohali',
        propertyType: 'Villa',
        bhk: '4',
        purpose: 'Rent',
        budgetMin: 40000,
        budgetMax: 60000,
        timeline: '0-3m',
        source: 'Referral',
        status: 'Qualified',
        notes: 'Needs pet-friendly villa with garden',
        tags: JSON.stringify(['pets', 'garden']),
        ownerId: userId,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: randomUUID(),
        fullName: 'Raj Patel',
        email: null,
        phone: '9876543212',
        city: 'Zirakpur',
        propertyType: 'Plot',
        bhk: null,
        purpose: 'Buy',
        budgetMin: 2000000,
        budgetMax: 3000000,
        timeline: '>6m',
        source: 'Walk-in',
        status: 'Contacted',
        notes: 'Looking for investment plot near highway',
        tags: JSON.stringify(['investment']),
        ownerId: userId,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ];

    await db.insert(buyers).values(sampleBuyers);
    
    console.log('Seeding complete!');
    process.exit(0);
  } catch (error) {
    console.error('Seeding failed:', error);
    process.exit(1);
  }
}

seed();
