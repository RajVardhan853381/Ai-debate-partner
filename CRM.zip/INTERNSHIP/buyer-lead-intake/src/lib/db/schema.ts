// src/lib/db/schema.ts
import { sqliteTable, text, integer } from 'drizzle-orm/sqlite-core';
import { relations } from 'drizzle-orm';

// Users table (for auth)
export const users = sqliteTable('users', {
  id: text('id').primaryKey(),
  email: text('email').unique().notNull(),
  name: text('name'),
  emailVerified: integer('emailVerified', { mode: 'timestamp_ms' }),
  image: text('image'),
  createdAt: integer('created_at', { mode: 'timestamp_ms' }).notNull().$defaultFn(() => new Date()),
});

// NextAuth required tables
export const accounts = sqliteTable('accounts', {
  id: text('id').primaryKey(),
  userId: text('userId').notNull().references(() => users.id, { onDelete: 'cascade' }),
  type: text('type').notNull(),
  provider: text('provider').notNull(),
  providerAccountId: text('providerAccountId').notNull(),
  refresh_token: text('refresh_token'),
  access_token: text('access_token'),
  expires_at: integer('expires_at'),
  token_type: text('token_type'),
  scope: text('scope'),
  id_token: text('id_token'),
  session_state: text('session_state'),
});

export const sessions = sqliteTable('sessions', {
  id: text('id').primaryKey(),
  sessionToken: text('sessionToken').unique().notNull(),
  userId: text('userId').notNull().references(() => users.id, { onDelete: 'cascade' }),
  expires: integer('expires', { mode: 'timestamp_ms' }).notNull(),
});

export const verificationTokens = sqliteTable('verificationTokens', {
  identifier: text('identifier').notNull(),
  token: text('token').unique().notNull(),
  expires: integer('expires', { mode: 'timestamp_ms' }).notNull(),
});

// Buyers table (main leads table)
export const buyers = sqliteTable('buyers', {
  id: text('id').primaryKey(),
  fullName: text('full_name', { length: 80 }).notNull(),
  email: text('email', { length: 255 }),
  phone: text('phone', { length: 15 }).notNull(),
  city: text('city').notNull(), // Chandigarh|Mohali|Zirakpur|Panchkula|Other
  propertyType: text('property_type').notNull(), // Apartment|Villa|Plot|Office|Retail
  bhk: text('bhk'), // Studio|1|2|3|4
  purpose: text('purpose').notNull(), // Buy|Rent
  budgetMin: integer('budget_min'),
  budgetMax: integer('budget_max'),
  timeline: text('timeline').notNull(), // 0-3m|3-6m|>6m|Exploring
  source: text('source').notNull(), // Website|Referral|Walk-in|Call|Other
  status: text('status').notNull().default('New'), // New|Qualified|Contacted|Visited|Negotiation|Converted|Dropped
  notes: text('notes'),
  tags: text('tags'), // JSON string array
  ownerId: text('owner_id').notNull().references(() => users.id),
  createdAt: integer('created_at', { mode: 'timestamp_ms' }).notNull().$defaultFn(() => new Date()),
  updatedAt: integer('updated_at', { mode: 'timestamp_ms' }).notNull().$defaultFn(() => new Date()),
});

// Buyer history table for audit trail
export const buyerHistory = sqliteTable('buyer_history', {
  id: text('id').primaryKey(),
  buyerId: text('buyer_id').notNull().references(() => buyers.id, { onDelete: 'cascade' }),
  changedBy: text('changed_by').notNull().references(() => users.id),
  changedAt: integer('changed_at', { mode: 'timestamp_ms' }).notNull().$defaultFn(() => new Date()),
  diff: text('diff').notNull(), // JSON string
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  buyers: many(buyers),
  buyerHistoryEntries: many(buyerHistory),
}));

export const buyersRelations = relations(buyers, ({ one, many }) => ({
  owner: one(users, {
    fields: [buyers.ownerId],
    references: [users.id],
  }),
  history: many(buyerHistory),
}));

export const buyerHistoryRelations = relations(buyerHistory, ({ one }) => ({
  buyer: one(buyers, {
    fields: [buyerHistory.buyerId],
    references: [buyers.id],
  }),
  changedBy: one(users, {
    fields: [buyerHistory.changedBy],
    references: [users.id],
  }),
}));

// Export types
export type User = typeof users.$inferSelect;
export type NewUser = typeof users.$inferInsert;

export type Buyer = typeof buyers.$inferSelect;
export type NewBuyer = typeof buyers.$inferInsert;

export type BuyerHistory = typeof buyerHistory.$inferSelect;
export type NewBuyerHistory = typeof buyerHistory.$inferInsert;