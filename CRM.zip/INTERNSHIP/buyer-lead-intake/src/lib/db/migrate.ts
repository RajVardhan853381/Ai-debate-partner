import { drizzle } from 'drizzle-orm/better-sqlite3';
import { migrate } from 'drizzle-orm/better-sqlite3/migrator';
import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';

async function runMigrations() {
  try {
    // Ensure database directory exists
    const dbDir = path.join(process.cwd(), 'database');
    if (!fs.existsSync(dbDir)) {
      fs.mkdirSync(dbDir, { recursive: true });
    }

    const dbPath = process.env.DATABASE_URL || './database/buyer_leads.db';
    console.log(`Using database at: ${dbPath}`);
    
    const sqlite = new Database(dbPath);
    sqlite.pragma('foreign_keys = ON');
    
    const db = drizzle(sqlite);

    console.log('Running migrations...');
    await migrate(db, { migrationsFolder: './drizzle' });
    console.log('Migrations complete!');
    
    sqlite.close();
    process.exit(0);
  } catch (error) {
    console.error('Migration failed:', error);
    process.exit(1);
  }
}

runMigrations();
