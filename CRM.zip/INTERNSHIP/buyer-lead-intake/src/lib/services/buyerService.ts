// src/lib/services/buyerService.ts
import { db, buyers, buyerHistory, Buyer, NewBuyer, BuyerHistory } from '@/lib/db';
import { eq, and, or, ilike, desc, asc, sql, count } from 'drizzle-orm';
import { BuyerFilters, CreateBuyerInput, UpdateBuyerInput } from '@/lib/validations/buyer';

export class BuyerService {
  // Create a new buyer
  static async create(data: CreateBuyerInput, userId: string): Promise<Buyer> {
    const buyerData: NewBuyer = {
      ...data,
      email: data.email || null,
      notes: data.notes || null,
      tags: data.tags || [],
      ownerId: userId,
      updatedAt: new Date(),
    };

    const [buyer] = await db.insert(buyers).values(buyerData).returning();

    // Create history entry
    await this.createHistoryEntry(buyer.id, userId, {
      created: { old: null, new: 'Lead created' }
    });

    return buyer;
  }

  // Get buyer by ID
  static async getById(id: string, userId?: string): Promise<Buyer | null> {
    const query = db.select().from(buyers).where(eq(buyers.id, id));
    
    // Add ownership check if userId provided
    if (userId) {
      query.where(and(eq(buyers.id, id), eq(buyers.ownerId, userId)));
    }

    const [buyer] = await query;
    return buyer || null;
  }

  // Update buyer
  static async update(
    id: string, 
    data: UpdateBuyerInput, 
    userId: string
  ): Promise<{ buyer?: Buyer; error?: string }> {
    // Get current buyer for concurrency check
    const current = await this.getById(id, userId);
    if (!current) {
      return { error: 'Buyer not found or access denied' };
    }

    // Check for concurrent modifications
    const currentUpdatedAt = current.updatedAt.toISOString();
    if (currentUpdatedAt !== data.updatedAt) {
      return { error: 'Record has been modified by another user. Please refresh and try again.' };
    }

    // Calculate diff for history
    const diff: Record<string, { old: any; new: any }> = {};
    Object.keys(data).forEach(key => {
      if (key !== 'id' && key !== 'updatedAt') {
        const oldVal = (current as any)[key];
        const newVal = (data as any)[key];
        if (JSON.stringify(oldVal) !== JSON.stringify(newVal)) {
          diff[key] = { old: oldVal, new: newVal };
        }
      }
    });

    if (Object.keys(diff).length === 0) {
      return { buyer: current }; // No changes
    }

    // Update buyer
    const updateData = { ...data };
    delete (updateData as any).id;
    delete (updateData as any).updatedAt;

    const [buyer] = await db
      .update(buyers)
      .set({ ...updateData, updatedAt: new Date() })
      .where(and(eq(buyers.id, id), eq(buyers.ownerId, userId)))
      .returning();

    // Create history entry
    await this.createHistoryEntry(id, userId, diff);

    return { buyer };
  }

  // List buyers with filters and pagination
  static async list(filters: BuyerFilters, userId?: string) {
    const { search, city, propertyType, status, timeline, page, sort, order } = filters;
    const pageSize = 10;
    const offset = (page - 1) * pageSize;

    // Build where conditions
    const conditions = [];
    
    if (userId) {
      conditions.push(eq(buyers.ownerId, userId));
    }
    
    if (search) {
      conditions.push(
        or(
          ilike(buyers.fullName, `%${search}%`),
          ilike(buyers.phone, `%${search}%`),
          ilike(buyers.email, `%${search}%`)
        )
      );
    }
    
    if (city) conditions.push(eq(buyers.city, city));
    if (propertyType) conditions.push(eq(buyers.propertyType, propertyType));
    if (status) conditions.push(eq(buyers.status, status));
    if (timeline) conditions.push(eq(buyers.timeline, timeline));

    const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

    // Get total count
    const [{ count: totalCount }] = await db
      .select({ count: count() })
      .from(buyers)
      .where(whereClause);

    // Get buyers
    const orderBy = order === 'desc' ? desc(buyers[sort]) : asc(buyers[sort]);
    
    const buyersList = await db
      .select()
      .from(buyers)
      .where(whereClause)
      .orderBy(orderBy)
      .limit(pageSize)
      .offset(offset);

    return {
      buyers: buyersList,
      pagination: {
        page,
        pageSize,
        totalCount,
        totalPages: Math.ceil(totalCount / pageSize),
      },
    };
  }

  // Delete buyer
  static async delete(id: string, userId: string): Promise<boolean> {
    const result = await db
      .delete(buyers)
      .where(and(eq(buyers.id, id), eq(buyers.ownerId, userId)))
      .returning();

    return result.length > 0;
  }

  // Get buyer history
  static async getHistory(buyerId: string, limit = 5): Promise<BuyerHistory[]> {
    return await db
      .select()
      .from(buyerHistory)
      .where(eq(buyerHistory.buyerId, buyerId))
      .orderBy(desc(buyerHistory.changedAt))
      .limit(limit);
  }

  // Create history entry
  static async createHistoryEntry(
    buyerId: string,
    changedBy: string,
    diff: Record<string, { old: any; new: any }>
  ): Promise<void> {
    await db.insert(buyerHistory).values({
      buyerId,
      changedBy,
      diff,
    });
  }

  // Bulk create from CSV import
  static async bulkCreate(
    buyersData: CreateBuyerInput[],
    userId: string
  ): Promise<{ created: number; errors: { row: number; error: string }[] }> {
    const errors: { row: number; error: string }[] = [];
    let created = 0;

    // Process in transaction
    await db.transaction(async (tx) => {
      for (let i = 0; i < buyersData.length; i++) {
        try {
          const buyerData: NewBuyer = {
            ...buyersData[i],
            email: buyersData[i].email || null,
            notes: buyersData[i].notes || null,
            tags: buyersData[i].tags || [],
            ownerId: userId,
            updatedAt: new Date(),
          };

          const [buyer] = await tx.insert(buyers).values(buyerData).returning();
          
          // Create history entry
          await tx.insert(buyerHistory).values({
            buyerId: buyer.id,
            changedBy: userId,
            diff: { created: { old: null, new: 'Lead imported from CSV' } },
          });

          created++;
        } catch (error) {
          errors.push({
            row: i + 1,
            error: error instanceof Error ? error.message : 'Unknown error',
          });
        }
      }
    });

    return { created, errors };
  }

  // Export buyers as CSV data
  static async exportCsv(filters: BuyerFilters, userId?: string) {
    // Get all matching records (no pagination for export)
    const { buyers: buyersList } = await this.list(
      { ...filters, page: 1 }, 
      userId
    );

    // Get all pages if there are more
    if (buyersList.length === 10) {
      // There might be more, get all
      const allBuyers: Buyer[] = [];
      let page = 1;
      let hasMore = true;

      while (hasMore) {
        const { buyers: pageBuyers } = await