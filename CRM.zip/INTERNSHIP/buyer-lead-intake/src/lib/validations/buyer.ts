// src/lib/validations/buyer.ts
import { z } from 'zod';

// Enum schemas matching database enums
export const CitySchema = z.enum(['Chandigarh', 'Mohali', 'Zirakpur', 'Panchkula', 'Other']);
export const PropertyTypeSchema = z.enum(['Apartment', 'Villa', 'Plot', 'Office', 'Retail']);
export const BhkSchema = z.enum(['Studio', '1', '2', '3', '4']);
export const PurposeSchema = z.enum(['Buy', 'Rent']);
export const TimelineSchema = z.enum(['0-3m', '3-6m', '>6m', 'Exploring']);
export const SourceSchema = z.enum(['Website', 'Referral', 'Walk-in', 'Call', 'Other']);
export const StatusSchema = z.enum(['New', 'Qualified', 'Contacted', 'Visited', 'Negotiation', 'Converted', 'Dropped']);

// Base buyer schema
const BaseBuyerSchema = z.object({
  fullName: z.string()
    .min(2, 'Full name must be at least 2 characters')
    .max(80, 'Full name must be at most 80 characters')
    .trim(),
  
  email: z.string()
    .email('Invalid email format')
    .optional()
    .or(z.literal('')),
  
  phone: z.string()
    .regex(/^\d{10,15}$/, 'Phone must be 10-15 digits')
    .transform(val => val.replace(/\D/g, '')),
  
  city: CitySchema,
  propertyType: PropertyTypeSchema,
  bhk: BhkSchema.optional(),
  purpose: PurposeSchema,
  
  budgetMin: z.number()
    .int('Budget minimum must be an integer')
    .min(0, 'Budget minimum must be positive')
    .optional(),
  
  budgetMax: z.number()
    .int('Budget maximum must be an integer')
    .min(0, 'Budget maximum must be positive')
    .optional(),
  
  timeline: TimelineSchema,
  source: SourceSchema,
  status: StatusSchema.default('New'),
  
  notes: z.string()
    .max(1000, 'Notes must be at most 1000 characters')
    .optional()
    .or(z.literal('')),
  
  tags: z.array(z.string().trim())
    .default([])
    .optional(),
});

// Create buyer schema with additional validation
export const CreateBuyerSchema = BaseBuyerSchema
  .refine(data => {
    // BHK is required for Apartment and Villa
    if (['Apartment', 'Villa'].includes(data.propertyType) && !data.bhk) {
      return false;
    }
    return true;
  }, {
    message: 'BHK is required for Apartment and Villa properties',
    path: ['bhk']
  })
  .refine(data => {
    // Budget max must be >= budget min when both are present
    if (data.budgetMin && data.budgetMax && data.budgetMax < data.budgetMin) {
      return false;
    }
    return true;
  }, {
    message: 'Budget maximum must be greater than or equal to budget minimum',
    path: ['budgetMax']
  });

// Update buyer schema (includes id and updatedAt for concurrency control)
export const UpdateBuyerSchema = CreateBuyerSchema.extend({
  id: z.string().uuid(),
  updatedAt: z.string().datetime(),
});

// Search and filter schema
export const BuyerFiltersSchema = z.object({
  search: z.string().optional(),
  city: CitySchema.optional(),
  propertyType: PropertyTypeSchema.optional(),
  status: StatusSchema.optional(),
  timeline: TimelineSchema.optional(),
  page: z.number().int().min(1).default(1),
  sort: z.enum(['updatedAt', 'fullName', 'createdAt']).default('updatedAt'),
  order: z.enum(['asc', 'desc']).default('desc'),
});

// CSV import schema
export const CsvBuyerSchema = z.object({
  fullName: z.string().min(2).max(80),
  email: z.string().email().optional().or(z.literal('')),
  phone: z.string().regex(/^\d{10,15}$/),
  city: CitySchema,
  propertyType: PropertyTypeSchema,
  bhk: BhkSchema.optional().or(z.literal('')),
  purpose: PurposeSchema,
  budgetMin: z.string().regex(/^\d*$/).transform(val => val ? parseInt(val) : undefined).optional(),
  budgetMax: z.string().regex(/^\d*$/).transform(val => val ? parseInt(val) : undefined).optional(),
  timeline: TimelineSchema,
  source: SourceSchema,
  notes: z.string().max(1000).optional().or(z.literal('')),
  tags: z.string().transform(val => val ? val.split(',').map(t => t.trim()).filter(Boolean) : []).optional(),
  status: StatusSchema.default('New'),
})
.refine(data => {
  if (['Apartment', 'Villa'].includes(data.propertyType) && !data.bhk) {
    return false;
  }
  return true;
}, {
  message: 'BHK is required for Apartment and Villa properties',
  path: ['bhk']
})
.refine(data => {
  if (data.budgetMin && data.budgetMax && data.budgetMax < data.budgetMin) {
    return false;
  }
  return true;
}, {
  message: 'Budget maximum must be greater than or equal to budget minimum',
  path: ['budgetMax']
});

// Type exports
export type CreateBuyerInput = z.infer<typeof CreateBuyerSchema>;
export type UpdateBuyerInput = z.infer<typeof UpdateBuyerSchema>;
export type BuyerFilters = z.infer<typeof BuyerFiltersSchema>;
export type CsvBuyerInput = z.infer<typeof CsvBuyerSchema>;