// Application State
let appState = {
    isAuthenticated: false,
    currentPage: 'dashboard',
    buyers: [],
    filteredBuyers: [],
    currentSort: { field: null, direction: 'asc' },
    currentFilters: {},
    pagination: { currentPage: 1, itemsPerPage: 25, totalItems: 0 },
    selectedBuyers: new Set(),
    editingBuyer: null
};

// Sample data and configuration
const sampleBuyers = [
    {
        "id": "1",
        "fullName": "Rajesh Kumar",
        "email": "rajesh@example.com",
        "phone": "9876543210",
        "city": "Mumbai",
        "propertyType": "Apartment",
        "bhk": "3BHK",
        "purpose": "Buy",
        "budgetMin": 8000000,
        "budgetMax": 12000000,
        "timeline": "3-6 months",
        "source": "Website",
        "notes": "Looking for premium apartment near Bandra",
        "tags": ["Premium", "Bandra", "Urgent"],
        "status": "Qualified",
        "createdAt": "2024-01-15T10:30:00Z",
        "updatedAt": "2024-01-16T14:20:00Z"
    },
    {
        "id": "2", 
        "fullName": "Priya Sharma",
        "email": "priya.sharma@email.com",
        "phone": "9123456789",
        "city": "Delhi",
        "propertyType": "Villa",
        "bhk": "4BHK",
        "purpose": "Buy",
        "budgetMin": 15000000,
        "budgetMax": 20000000,
        "timeline": "6-12 months",
        "source": "Referral",
        "notes": "Interested in villa with garden space",
        "tags": ["Villa", "Garden", "Family"],
        "status": "New",
        "createdAt": "2024-01-14T09:15:00Z",
        "updatedAt": "2024-01-14T09:15:00Z"
    },
    {
        "id": "3",
        "fullName": "Mohammed Ali",
        "email": "",
        "phone": "9988776655",
        "city": "Bangalore",
        "propertyType": "Apartment",
        "bhk": "2BHK", 
        "purpose": "Rent",
        "budgetMin": 25000,
        "budgetMax": 35000,
        "timeline": "Immediate",
        "source": "Social Media",
        "notes": "IT professional looking for rental near tech parks",
        "tags": ["IT Professional", "Tech Park", "Rental"],
        "status": "Contacted",
        "createdAt": "2024-01-13T16:45:00Z",
        "updatedAt": "2024-01-15T11:30:00Z"
    },
    {
        "id": "4",
        "fullName": "Sunita Patel",
        "email": "sunita.patel@gmail.com",
        "phone": "9876512345",
        "city": "Pune",
        "propertyType": "Plot",
        "bhk": "",
        "purpose": "Buy",
        "budgetMin": 3000000,
        "budgetMax": 5000000,
        "timeline": "1+ years",
        "source": "Advertisement",
        "notes": "Looking for plot for future construction",
        "tags": ["Plot", "Construction", "Investment"],
        "status": "Proposal Sent",
        "createdAt": "2024-01-12T08:20:00Z",
        "updatedAt": "2024-01-17T13:45:00Z"
    },
    {
        "id": "5",
        "fullName": "Arjun Singh",
        "email": "arjun.singh@company.com",
        "phone": "9765432100",
        "city": "Chennai",
        "propertyType": "Office",
        "bhk": "",
        "purpose": "Rent",
        "budgetMin": 100000,
        "budgetMax": 150000,
        "timeline": "1-3 months",
        "source": "Cold Call",
        "notes": "Startup looking for office space",
        "tags": ["Startup", "Office", "IT Corridor"],
        "status": "Negotiating",
        "createdAt": "2024-01-11T14:10:00Z",
        "updatedAt": "2024-01-18T10:15:00Z"
    },
    {
        "id": "6",
        "fullName": "Kavya Reddy",
        "email": "kavya.reddy@email.com",
        "phone": "9654321098",
        "city": "Hyderabad",
        "propertyType": "Apartment",
        "bhk": "2BHK",
        "purpose": "Buy",
        "budgetMin": 4500000,
        "budgetMax": 6000000,
        "timeline": "3-6 months",
        "source": "Walk-in",
        "notes": "First time home buyer, needs guidance",
        "tags": ["First Time Buyer", "Guidance Needed"],
        "status": "Qualified",
        "createdAt": "2024-01-10T11:30:00Z",
        "updatedAt": "2024-01-16T09:20:00Z"
    },
    {
        "id": "7",
        "fullName": "Vikram Agarwal",
        "email": "vikram@business.com",
        "phone": "9543210987",
        "city": "Kolkata",
        "propertyType": "Shop",
        "bhk": "",
        "purpose": "Buy",
        "budgetMin": 2000000,
        "budgetMax": 3500000,
        "timeline": "1-3 months",
        "source": "Website",
        "notes": "Looking for shop in commercial area",
        "tags": ["Commercial", "Shop", "Business"],
        "status": "Closed Won",
        "createdAt": "2024-01-09T15:45:00Z",
        "updatedAt": "2024-01-19T14:30:00Z"
    },
    {
        "id": "8",
        "fullName": "Meera Joshi",
        "email": "meera.joshi@email.com",
        "phone": "9432109876",
        "city": "Ahmedabad",
        "propertyType": "Apartment",
        "bhk": "3BHK",
        "purpose": "Rent",
        "budgetMin": 20000,
        "budgetMax": 30000,
        "timeline": "Immediate",
        "source": "Referral",
        "notes": "Relocating for job, urgent requirement",
        "tags": ["Job Relocation", "Urgent", "Immediate"],
        "status": "Contacted",
        "createdAt": "2024-01-08T12:15:00Z",
        "updatedAt": "2024-01-14T16:40:00Z"
    },
    {
        "id": "9",
        "fullName": "Rohit Gupta",
        "email": "",
        "phone": "9321098765",
        "city": "Jaipur",
        "propertyType": "Villa",
        "bhk": "5BHK+",
        "purpose": "Buy",
        "budgetMin": 25000000,
        "budgetMax": 35000000,
        "timeline": "6-12 months",
        "source": "Advertisement",
        "notes": "Looking for luxury villa with modern amenities",
        "tags": ["Luxury", "Modern Amenities", "High Budget"],
        "status": "New",
        "createdAt": "2024-01-07T09:30:00Z",
        "updatedAt": "2024-01-07T09:30:00Z"
    },
    {
        "id": "10",
        "fullName": "Anita Nair",
        "email": "anita.nair@email.com",
        "phone": "9210987654",
        "city": "Mumbai",
        "propertyType": "Warehouse",
        "bhk": "",
        "purpose": "Rent",
        "budgetMin": 200000,
        "budgetMax": 300000,
        "timeline": "1-3 months",
        "source": "Cold Call",
        "notes": "E-commerce business needs warehouse space",
        "tags": ["E-commerce", "Warehouse", "Business"],
        "status": "Closed Lost",
        "createdAt": "2024-01-06T13:20:00Z",
        "updatedAt": "2024-01-20T11:45:00Z"
    }
];

const config = {
    cities: ["Mumbai", "Delhi", "Bangalore", "Hyderabad", "Pune", "Chennai", "Kolkata", "Ahmedabad", "Jaipur", "Other"],
    propertyTypes: ["Apartment", "Villa", "Plot", "Office", "Shop", "Warehouse"],
    bhkOptions: ["1BHK", "2BHK", "3BHK", "4BHK", "5BHK+"],
    purposes: ["Buy", "Rent"],
    timelines: ["Immediate", "1-3 months", "3-6 months", "6-12 months", "1+ years"],
    sources: ["Website", "Referral", "Advertisement", "Social Media", "Cold Call", "Walk-in"],
    statuses: ["New", "Contacted", "Qualified", "Proposal Sent", "Negotiating", "Closed Won", "Closed Lost"],
    demoCredentials: {
        email: "demo@realestatecrm.com",
        password: "demo123"
    }
};

// Utility Functions
function generateId() {
    return Date.now().toString() + Math.random().toString(36).substr(2, 9);
}

function formatCurrency(amount) {
    if (!amount) return '';
    return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        maximumFractionDigits: 0
    }).format(amount);
}

function formatDate(dateString) {
    return new Date(dateString).toLocaleDateString('en-IN', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

function showToast(message, type = 'success') {
    const toast = document.getElementById('toast');
    const toastMessage = document.getElementById('toastMessage');
    
    toast.className = `toast ${type}`;
    toastMessage.textContent = message;
    toast.classList.remove('hidden');
    
    setTimeout(() => {
        toast.classList.add('hidden');
    }, 3000);
}

function showConfirmDialog(title, message, onConfirm) {
    const modal = document.getElementById('confirmModal');
    const titleEl = document.getElementById('confirmTitle');
    const messageEl = document.getElementById('confirmMessage');
    const confirmBtn = document.getElementById('confirmAction');
    
    titleEl.textContent = title;
    messageEl.textContent = message;
    modal.classList.remove('hidden');
    
    // Remove existing event listeners
    const newConfirmBtn = confirmBtn.cloneNode(true);
    confirmBtn.parentNode.replaceChild(newConfirmBtn, confirmBtn);
    
    newConfirmBtn.addEventListener('click', () => {
        modal.classList.add('hidden');
        onConfirm();
    });
}

// Authentication Functions
function handleLogin(e) {
    e.preventDefault();
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    
    if (email === config.demoCredentials.email && password === config.demoCredentials.password) {
        login();
    } else {
        showToast('Invalid credentials', 'error');
    }
}

function handleDemoLogin(e) {
    e.preventDefault();
    login();
}

function login() {
    appState.isAuthenticated = true;
    document.getElementById('loginPage').classList.add('hidden');
    document.getElementById('mainApp').classList.remove('hidden');
    initApp();
    showToast('Welcome to Real Estate CRM!');
}

function handleLogout() {
    showConfirmDialog('Logout', 'Are you sure you want to logout?', () => {
        appState.isAuthenticated = false;
        document.getElementById('mainApp').classList.add('hidden');
        document.getElementById('loginPage').classList.remove('hidden');
        showToast('Logged out successfully');
    });
}

// Navigation Functions
function initNavigation() {
    const navItems = document.querySelectorAll('.nav-item');
    const sidebarToggle = document.getElementById('sidebarToggle');
    const sidebar = document.getElementById('sidebar');
    
    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const page = item.dataset.page;
            navigateToPage(page);
        });
    });
    
    if (sidebarToggle && sidebar) {
        sidebarToggle.addEventListener('click', () => {
            sidebar.classList.toggle('open');
        });
        
        // Close sidebar on mobile when clicking outside
        document.addEventListener('click', (e) => {
            if (window.innerWidth <= 768 && !sidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
                sidebar.classList.remove('open');
            }
        });
    }
}

function navigateToPage(page) {
    // Update navigation
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.toggle('active', item.dataset.page === page);
    });
    
    // Update pages
    document.querySelectorAll('.page').forEach(pageEl => {
        pageEl.classList.toggle('active', pageEl.id === `${page}Page`);
    });
    
    appState.currentPage = page;
    
    // Initialize page-specific functionality
    switch (page) {
        case 'dashboard':
            initDashboard();
            break;
        case 'buyers':
            initBuyersPage();
            break;
        case 'import-export':
            initImportExportPage();
            break;
        case 'settings':
            initSettingsPage();
            break;
    }
    
    // Close mobile sidebar
    const sidebar = document.getElementById('sidebar');
    if (sidebar) {
        sidebar.classList.remove('open');
    }
}

// Dashboard Functions
function initDashboard() {
    updateDashboardStats();
    updateRecentActivity();
    // Initialize charts with a delay to ensure elements are visible
    setTimeout(() => {
        initCharts();
    }, 100);
}

function updateDashboardStats() {
    const totalLeads = appState.buyers.length;
    const activeLeads = appState.buyers.filter(b => !['Closed Won', 'Closed Lost'].includes(b.status)).length;
    const qualifiedLeads = appState.buyers.filter(b => b.status === 'Qualified').length;
    const closedWonLeads = appState.buyers.filter(b => b.status === 'Closed Won').length;
    
    document.getElementById('totalLeads').textContent = totalLeads;
    document.getElementById('activeLeads').textContent = activeLeads;
    document.getElementById('qualifiedLeads').textContent = qualifiedLeads;
    document.getElementById('closedWonLeads').textContent = closedWonLeads;
}

function updateRecentActivity() {
    const recentActivity = document.getElementById('recentActivity');
    const activities = appState.buyers
        .sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt))
        .slice(0, 5)
        .map(buyer => ({
            text: `${buyer.fullName} - ${buyer.status}`,
            time: formatDate(buyer.updatedAt),
            icon: getStatusIcon(buyer.status)
        }));
    
    recentActivity.innerHTML = activities.map(activity => `
        <div class="activity-item">
            <div class="activity-icon" style="background: var(--color-primary);">
                ${activity.icon}
            </div>
            <div class="activity-content">
                <p class="activity-text">${activity.text}</p>
                <div class="activity-time">${activity.time}</div>
            </div>
        </div>
    `).join('');
}

function getStatusIcon(status) {
    const icons = {
        'New': '🆕',
        'Contacted': '📞',
        'Qualified': '✅',
        'Proposal Sent': '📋',
        'Negotiating': '🤝',
        'Closed Won': '🎉',
        'Closed Lost': '❌'
    };
    return icons[status] || '📊';
}

function initCharts() {
    try {
        initSourceChart();
        initTimelineChart();
    } catch (error) {
        console.error('Error initializing charts:', error);
    }
}

function initSourceChart() {
    const canvas = document.getElementById('sourceChart');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    const sourceData = config.sources.map(source => 
        appState.buyers.filter(buyer => buyer.source === source).length
    );
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: config.sources,
            datasets: [{
                data: sourceData,
                backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5', '#5D878F', '#DB4545']
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
}

function initTimelineChart() {
    const canvas = document.getElementById('timelineChart');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    const timelineData = config.timelines.map(timeline => 
        appState.buyers.filter(buyer => buyer.timeline === timeline).length
    );
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: config.timelines,
            datasets: [{
                label: 'Buyers',
                data: timelineData,
                backgroundColor: '#1FB8CD'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

// Buyers Management Functions
function initBuyersPage() {
    initFilters();
    initBuyersTable();
    initBuyerActions();
    applyFilters();
}

function initFilters() {
    // Populate filter dropdowns
    populateSelect('cityFilter', config.cities);
    populateSelect('propertyTypeFilter', config.propertyTypes);
    populateSelect('bhkFilter', config.bhkOptions);
    populateSelect('purposeFilter', config.purposes);
    populateSelect('timelineFilter', config.timelines);
    populateSelect('statusFilter', config.statuses);
    populateSelect('sourceFilter', config.sources);
    
    // Add event listeners
    document.querySelectorAll('.filters-sidebar select, .filters-sidebar input').forEach(element => {
        element.addEventListener('input', applyFilters);
    });
    
    const clearFiltersBtn = document.getElementById('clearFilters');
    const globalSearch = document.getElementById('globalSearch');
    
    if (clearFiltersBtn) {
        clearFiltersBtn.addEventListener('click', clearAllFilters);
    }
    
    if (globalSearch) {
        globalSearch.addEventListener('input', applyFilters);
    }
}

function populateSelect(selectId, options) {
    const select = document.getElementById(selectId);
    if (!select) return;
    
    select.innerHTML = select.children[0].outerHTML; // Keep first option
    options.forEach(option => {
        const optionEl = document.createElement('option');
        optionEl.value = option;
        optionEl.textContent = option;
        select.appendChild(optionEl);
    });
}

function clearAllFilters() {
    document.querySelectorAll('.filters-sidebar select').forEach(select => {
        select.selectedIndex = 0;
    });
    document.querySelectorAll('.filters-sidebar input').forEach(input => {
        input.value = '';
    });
    const globalSearch = document.getElementById('globalSearch');
    if (globalSearch) {
        globalSearch.value = '';
    }
    applyFilters();
}

function applyFilters() {
    const globalSearch = document.getElementById('globalSearch');
    const searchValue = globalSearch ? globalSearch.value.toLowerCase() : '';
    
    const filters = {
        search: searchValue,
        city: getElementValue('cityFilter'),
        propertyType: getElementValue('propertyTypeFilter'),
        bhk: getElementValue('bhkFilter'),
        purpose: getElementValue('purposeFilter'),
        budgetMin: getElementValue('budgetMinFilter'),
        budgetMax: getElementValue('budgetMaxFilter'),
        timeline: getElementValue('timelineFilter'),
        status: getElementValue('statusFilter'),
        source: getElementValue('sourceFilter')
    };
    
    function getElementValue(id) {
        const element = document.getElementById(id);
        return element ? element.value : '';
    }
    
    appState.currentFilters = filters;
    appState.filteredBuyers = appState.buyers.filter(buyer => {
        if (filters.search && !buyer.fullName.toLowerCase().includes(filters.search) &&
            !buyer.phone.includes(filters.search) && !buyer.email.toLowerCase().includes(filters.search)) {
            return false;
        }
        if (filters.city && buyer.city !== filters.city) return false;
        if (filters.propertyType && buyer.propertyType !== filters.propertyType) return false;
        if (filters.bhk && buyer.bhk !== filters.bhk) return false;
        if (filters.purpose && buyer.purpose !== filters.purpose) return false;
        if (filters.timeline && buyer.timeline !== filters.timeline) return false;
        if (filters.status && buyer.status !== filters.status) return false;
        if (filters.source && buyer.source !== filters.source) return false;
        if (filters.budgetMin && buyer.budgetMax && buyer.budgetMax < parseInt(filters.budgetMin)) return false;
        if (filters.budgetMax && buyer.budgetMin && buyer.budgetMin > parseInt(filters.budgetMax)) return false;
        
        return true;
    });
    
    appState.pagination.currentPage = 1;
    appState.pagination.totalItems = appState.filteredBuyers.length;
    
    renderBuyersTable();
    updatePagination();
}

function sortBuyers(field) {
    if (appState.currentSort.field === field) {
        appState.currentSort.direction = appState.currentSort.direction === 'asc' ? 'desc' : 'asc';
    } else {
        appState.currentSort.field = field;
        appState.currentSort.direction = 'asc';
    }
    
    appState.filteredBuyers.sort((a, b) => {
        let aVal = a[field] || '';
        let bVal = b[field] || '';
        
        if (typeof aVal === 'string') {
            aVal = aVal.toLowerCase();
            bVal = bVal.toLowerCase();
        }
        
        if (appState.currentSort.direction === 'asc') {
            return aVal > bVal ? 1 : -1;
        } else {
            return aVal < bVal ? 1 : -1;
        }
    });
    
    renderBuyersTable();
}

function initBuyersTable() {
    // Add sorting event listeners
    document.querySelectorAll('.sortable').forEach(th => {
        th.addEventListener('click', () => {
            const field = th.dataset.sort;
            sortBuyers(field);
            
            // Update sort indicators
            document.querySelectorAll('.sortable').forEach(header => {
                header.classList.remove('asc', 'desc');
            });
            th.classList.add(appState.currentSort.direction);
        });
    });
    
    // Select all checkbox
    const selectAll = document.getElementById('selectAll');
    if (selectAll) {
        selectAll.addEventListener('change', (e) => {
            const isChecked = e.target.checked;
            document.querySelectorAll('.buyer-checkbox').forEach(checkbox => {
                checkbox.checked = isChecked;
                const buyerId = checkbox.dataset.buyerId;
                if (isChecked) {
                    appState.selectedBuyers.add(buyerId);
                } else {
                    appState.selectedBuyers.delete(buyerId);
                }
            });
            updateBulkActions();
        });
    }
    
    // Pagination
    const prevPage = document.getElementById('prevPage');
    const nextPage = document.getElementById('nextPage');
    
    if (prevPage) {
        prevPage.addEventListener('click', () => {
            if (appState.pagination.currentPage > 1) {
                appState.pagination.currentPage--;
                renderBuyersTable();
                updatePagination();
            }
        });
    }
    
    if (nextPage) {
        nextPage.addEventListener('click', () => {
            const totalPages = Math.ceil(appState.pagination.totalItems / appState.pagination.itemsPerPage);
            if (appState.pagination.currentPage < totalPages) {
                appState.pagination.currentPage++;
                renderBuyersTable();
                updatePagination();
            }
        });
    }
}

function renderBuyersTable() {
    const tbody = document.getElementById('buyersTableBody');
    if (!tbody) return;
    
    const { currentPage, itemsPerPage } = appState.pagination;
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const pageData = appState.filteredBuyers.slice(startIndex, endIndex);
    
    tbody.innerHTML = pageData.map(buyer => `
        <tr>
            <td><input type="checkbox" class="buyer-checkbox" data-buyer-id="${buyer.id}"></td>
            <td>${buyer.fullName}</td>
            <td>${buyer.phone}</td>
            <td>${buyer.city}</td>
            <td>${buyer.propertyType}</td>
            <td>${buyer.bhk || '-'}</td>
            <td>${buyer.purpose}</td>
            <td>${formatBudgetRange(buyer.budgetMin, buyer.budgetMax)}</td>
            <td>${buyer.timeline}</td>
            <td><span class="status-badge status-${buyer.status.toLowerCase().replace(/\s+/g, '-')}">${buyer.status}</span></td>
            <td>
                <div class="action-buttons">
                    <button class="action-btn" onclick="viewBuyer('${buyer.id}')" title="View">👁️</button>
                    <button class="action-btn" onclick="editBuyer('${buyer.id}')" title="Edit">✏️</button>
                    <button class="action-btn" onclick="deleteBuyer('${buyer.id}')" title="Delete">🗑️</button>
                </div>
            </td>
        </tr>
    `).join('');
    
    // Add event listeners to checkboxes
    document.querySelectorAll('.buyer-checkbox').forEach(checkbox => {
        checkbox.addEventListener('change', (e) => {
            const buyerId = e.target.dataset.buyerId;
            if (e.target.checked) {
                appState.selectedBuyers.add(buyerId);
            } else {
                appState.selectedBuyers.delete(buyerId);
            }
            updateBulkActions();
        });
    });
    
    const buyersCount = document.getElementById('buyersCount');
    if (buyersCount) {
        buyersCount.textContent = `${appState.filteredBuyers.length} buyers`;
    }
}

function formatBudgetRange(min, max) {
    if (!min && !max) return '-';
    if (!min) return `Up to ${formatCurrency(max)}`;
    if (!max) return `From ${formatCurrency(min)}`;
    return `${formatCurrency(min)} - ${formatCurrency(max)}`;
}

function updatePagination() {
    const { currentPage, itemsPerPage, totalItems } = appState.pagination;
    const totalPages = Math.ceil(totalItems / itemsPerPage);
    const startItem = totalItems === 0 ? 0 : (currentPage - 1) * itemsPerPage + 1;
    const endItem = Math.min(currentPage * itemsPerPage, totalItems);
    
    const paginationStart = document.getElementById('paginationStart');
    const paginationEnd = document.getElementById('paginationEnd');
    const paginationTotal = document.getElementById('paginationTotal');
    const currentPageEl = document.getElementById('currentPage');
    const prevPage = document.getElementById('prevPage');
    const nextPage = document.getElementById('nextPage');
    
    if (paginationStart) paginationStart.textContent = startItem;
    if (paginationEnd) paginationEnd.textContent = endItem;
    if (paginationTotal) paginationTotal.textContent = totalItems;
    if (currentPageEl) currentPageEl.textContent = `${currentPage} / ${totalPages}`;
    
    if (prevPage) prevPage.disabled = currentPage === 1;
    if (nextPage) nextPage.disabled = currentPage === totalPages || totalPages === 0;
}

function updateBulkActions() {
    const bulkDeleteBtn = document.getElementById('bulkDeleteBtn');
    if (!bulkDeleteBtn) return;
    
    bulkDeleteBtn.disabled = appState.selectedBuyers.size === 0;
    
    if (appState.selectedBuyers.size > 0) {
        bulkDeleteBtn.textContent = `Delete Selected (${appState.selectedBuyers.size})`;
    } else {
        bulkDeleteBtn.textContent = 'Delete Selected';
    }
}

function initBuyerActions() {
    const addBuyerBtn = document.getElementById('addBuyerBtn');
    const bulkDeleteBtn = document.getElementById('bulkDeleteBtn');
    const exportBtn = document.getElementById('exportBtn');
    
    if (addBuyerBtn) {
        addBuyerBtn.addEventListener('click', () => openBuyerModal());
    }
    
    if (bulkDeleteBtn) {
        bulkDeleteBtn.addEventListener('click', handleBulkDelete);
    }
    
    if (exportBtn) {
        exportBtn.addEventListener('click', exportBuyers);
    }
}

function handleBulkDelete() {
    const count = appState.selectedBuyers.size;
    showConfirmDialog(
        'Delete Buyers',
        `Are you sure you want to delete ${count} selected buyer(s)?`,
        () => {
            appState.buyers = appState.buyers.filter(buyer => !appState.selectedBuyers.has(buyer.id));
            appState.selectedBuyers.clear();
            applyFilters();
            showToast(`${count} buyer(s) deleted successfully`);
        }
    );
}

// Buyer Modal Functions
function initBuyerModal() {
    const modal = document.getElementById('buyerModal');
    const form = document.getElementById('buyerForm');
    const closeBtn = document.getElementById('closeModal');
    const cancelBtn = document.getElementById('cancelBtn');
    
    if (!modal || !form) return;
    
    // Populate form dropdowns
    populateSelect('buyerCity', config.cities);
    populateSelect('buyerPropertyType', config.propertyTypes);
    populateSelect('buyerBhk', config.bhkOptions);
    populateSelect('buyerPurpose', config.purposes);
    populateSelect('buyerTimeline', config.timelines);
    populateSelect('buyerSource', config.sources);
    populateSelect('buyerStatus', config.statuses);
    
    // Property type change handler for BHK visibility
    const propertyTypeSelect = document.getElementById('buyerPropertyType');
    if (propertyTypeSelect) {
        propertyTypeSelect.addEventListener('change', (e) => {
            const bhkGroup = document.getElementById('bhkGroup');
            const requiresBhk = ['Apartment', 'Villa'].includes(e.target.value);
            if (bhkGroup) {
                bhkGroup.style.display = requiresBhk ? 'block' : 'none';
            }
            
            const bhkSelect = document.getElementById('buyerBhk');
            if (bhkSelect) {
                if (requiresBhk) {
                    bhkSelect.required = true;
                } else {
                    bhkSelect.required = false;
                    bhkSelect.value = '';
                }
            }
        });
    }
    
    // Notes character counter
    const notesTextarea = document.getElementById('buyerNotes');
    if (notesTextarea) {
        notesTextarea.addEventListener('input', (e) => {
            const charCount = e.target.value.length;
            const charCountEl = document.querySelector('.char-count');
            if (charCountEl) {
                charCountEl.textContent = `${charCount}/1000`;
            }
        });
    }
    
    // Tags functionality
    initTagsInput();
    
    // Form validation
    form.addEventListener('input', validateForm);
    form.addEventListener('submit', handleBuyerSubmit);
    
    if (closeBtn) {
        closeBtn.addEventListener('click', closeBuyerModal);
    }
    
    if (cancelBtn) {
        cancelBtn.addEventListener('click', closeBuyerModal);
    }
    
    // Close modal on backdrop click
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            closeBuyerModal();
        }
    });
}

function initTagsInput() {
    const tagsInput = document.getElementById('buyerTags');
    const tagsList = document.getElementById('tagsList');
    if (!tagsInput || !tagsList) return;
    
    let tags = [];
    
    tagsInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ',') {
            e.preventDefault();
            const tag = e.target.value.trim();
            if (tag && !tags.includes(tag) && tags.length < 20) {
                tags.push(tag);
                renderTags();
                e.target.value = '';
            }
        }
    });
    
    function renderTags() {
        tagsList.innerHTML = tags.map(tag => `
            <span class="tag">
                ${tag}
                <button type="button" class="tag-remove" onclick="removeTag('${tag}')">&times;</button>
            </span>
        `).join('');
    }
    
    window.removeTag = function(tagToRemove) {
        tags = tags.filter(tag => tag !== tagToRemove);
        renderTags();
    };
    
    window.getTags = () => tags;
    window.setTags = (newTags) => {
        tags = newTags || [];
        renderTags();
    };
}

function openBuyerModal(buyer = null) {
    const modal = document.getElementById('buyerModal');
    const form = document.getElementById('buyerForm');
    const title = document.getElementById('modalTitle');
    
    if (!modal || !form || !title) return;
    
    appState.editingBuyer = buyer;
    
    if (buyer) {
        title.textContent = 'Edit Buyer';
        populateBuyerForm(buyer);
    } else {
        title.textContent = 'Add New Buyer';
        form.reset();
        if (window.setTags) window.setTags([]);
        const charCount = document.querySelector('.char-count');
        if (charCount) charCount.textContent = '0/1000';
        
        // Set default status
        const statusSelect = document.getElementById('buyerStatus');
        if (statusSelect) statusSelect.value = 'New';
    }
    
    // Show/hide BHK based on property type
    const propertyType = document.getElementById('buyerPropertyType');
    const bhkGroup = document.getElementById('bhkGroup');
    if (propertyType && bhkGroup) {
        const requiresBhk = ['Apartment', 'Villa'].includes(propertyType.value);
        bhkGroup.style.display = requiresBhk ? 'block' : 'none';
    }
    
    modal.classList.remove('hidden');
    const fullNameInput = document.getElementById('fullName');
    if (fullNameInput) fullNameInput.focus();
}

function populateBuyerForm(buyer) {
    const fields = [
        { id: 'buyerId', value: buyer.id },
        { id: 'fullName', value: buyer.fullName },
        { id: 'buyerEmail', value: buyer.email || '' },
        { id: 'buyerPhone', value: buyer.phone },
        { id: 'buyerCity', value: buyer.city },
        { id: 'buyerPropertyType', value: buyer.propertyType },
        { id: 'buyerBhk', value: buyer.bhk || '' },
        { id: 'buyerPurpose', value: buyer.purpose },
        { id: 'budgetMin', value: buyer.budgetMin || '' },
        { id: 'budgetMax', value: buyer.budgetMax || '' },
        { id: 'buyerTimeline', value: buyer.timeline },
        { id: 'buyerSource', value: buyer.source },
        { id: 'buyerStatus', value: buyer.status },
        { id: 'buyerNotes', value: buyer.notes || '' }
    ];
    
    fields.forEach(field => {
        const element = document.getElementById(field.id);
        if (element) element.value = field.value;
    });
    
    const charCount = (buyer.notes || '').length;
    const charCountEl = document.querySelector('.char-count');
    if (charCountEl) {
        charCountEl.textContent = `${charCount}/1000`;
    }
    
    if (window.setTags) {
        window.setTags(buyer.tags || []);
    }
}

function closeBuyerModal() {
    const modal = document.getElementById('buyerModal');
    if (modal) {
        modal.classList.add('hidden');
    }
    appState.editingBuyer = null;
}

function validateForm() {
    const form = document.getElementById('buyerForm');
    if (!form) return true;
    
    const inputs = form.querySelectorAll('input[required], select[required]');
    let isValid = true;
    
    inputs.forEach(input => {
        const errorEl = input.parentElement.querySelector('.error-message');
        let error = '';
        
        if (!input.value.trim()) {
            error = 'This field is required';
            isValid = false;
        } else {
            // Specific validations
            switch (input.id) {
                case 'fullName':
                    if (input.value.length < 2 || input.value.length > 80) {
                        error = 'Name must be between 2-80 characters';
                        isValid = false;
                    }
                    break;
                case 'buyerEmail':
                    if (input.value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.value)) {
                        error = 'Please enter a valid email';
                        isValid = false;
                    }
                    break;
                case 'buyerPhone':
                    if (!/^[0-9]{10,15}$/.test(input.value)) {
                        error = 'Phone must be 10-15 digits';
                        isValid = false;
                    }
                    break;
                case 'budgetMax':
                    const budgetMin = document.getElementById('budgetMin');
                    if (budgetMin && budgetMin.value && input.value && parseInt(input.value) < parseInt(budgetMin.value)) {
                        error = 'Max budget must be greater than min budget';
                        isValid = false;
                    }
                    break;
            }
        }
        
        if (errorEl) {
            errorEl.textContent = error;
        }
        input.classList.toggle('error', !!error);
    });
    
    // BHK validation for Apartment/Villa
    const propertyType = document.getElementById('buyerPropertyType');
    const bhk = document.getElementById('buyerBhk');
    const bhkError = document.querySelector('#bhkGroup .error-message');
    
    if (propertyType && bhk && bhkError) {
        if (['Apartment', 'Villa'].includes(propertyType.value) && !bhk.value) {
            bhkError.textContent = 'BHK is required for apartments and villas';
            isValid = false;
        } else {
            bhkError.textContent = '';
        }
    }
    
    return isValid;
}

function handleBuyerSubmit(e) {
    e.preventDefault();
    
    if (!validateForm()) {
        showToast('Please fix the errors in the form', 'error');
        return;
    }
    
    const buyerData = {
        fullName: document.getElementById('fullName').value,
        email: document.getElementById('buyerEmail').value,
        phone: document.getElementById('buyerPhone').value,
        city: document.getElementById('buyerCity').value,
        propertyType: document.getElementById('buyerPropertyType').value,
        bhk: document.getElementById('buyerBhk').value,
        purpose: document.getElementById('buyerPurpose').value,
        budgetMin: document.getElementById('budgetMin').value ? parseInt(document.getElementById('budgetMin').value) : null,
        budgetMax: document.getElementById('budgetMax').value ? parseInt(document.getElementById('budgetMax').value) : null,
        timeline: document.getElementById('buyerTimeline').value,
        source: document.getElementById('buyerSource').value,
        status: document.getElementById('buyerStatus').value,
        notes: document.getElementById('buyerNotes').value,
        tags: window.getTags ? window.getTags() : [],
        updatedAt: new Date().toISOString()
    };
    
    if (appState.editingBuyer) {
        // Update existing buyer
        const index = appState.buyers.findIndex(b => b.id === appState.editingBuyer.id);
        if (index !== -1) {
            appState.buyers[index] = { ...appState.buyers[index], ...buyerData };
            showToast('Buyer updated successfully');
        }
    } else {
        // Add new buyer
        buyerData.id = generateId();
        buyerData.createdAt = new Date().toISOString();
        appState.buyers.push(buyerData);
        showToast('Buyer added successfully');
    }
    
    closeBuyerModal();
    applyFilters();
    
    if (appState.currentPage === 'dashboard') {
        updateDashboardStats();
        updateRecentActivity();
    }
}

// Buyer Actions (Global functions for onclick handlers)
window.viewBuyer = function(id) {
    const buyer = appState.buyers.find(b => b.id === id);
    if (!buyer) return;
    
    const modal = document.getElementById('buyerDetailsModal');
    const content = document.getElementById('buyerDetailsContent');
    
    if (!modal || !content) return;
    
    content.innerHTML = `
        <div class="buyer-details">
            <div class="details-section">
                <h4>Basic Information</h4>
                <div class="details-group">
                    <span class="details-label">Full Name</span>
                    <span class="details-value">${buyer.fullName}</span>
                </div>
                <div class="details-group">
                    <span class="details-label">Email</span>
                    <span class="details-value">${buyer.email || 'Not provided'}</span>
                </div>
                <div class="details-group">
                    <span class="details-label">Phone</span>
                    <span class="details-value">${buyer.phone}</span>
                </div>
                <div class="details-group">
                    <span class="details-label">City</span>
                    <span class="details-value">${buyer.city}</span>
                </div>
            </div>
            
            <div class="details-section">
                <h4>Property Requirements</h4>
                <div class="details-group">
                    <span class="details-label">Property Type</span>
                    <span class="details-value">${buyer.propertyType}</span>
                </div>
                ${buyer.bhk ? `
                <div class="details-group">
                    <span class="details-label">BHK</span>
                    <span class="details-value">${buyer.bhk}</span>
                </div>
                ` : ''}
                <div class="details-group">
                    <span class="details-label">Purpose</span>
                    <span class="details-value">${buyer.purpose}</span>
                </div>
                <div class="details-group">
                    <span class="details-label">Budget</span>
                    <span class="details-value">${formatBudgetRange(buyer.budgetMin, buyer.budgetMax)}</span>
                </div>
                <div class="details-group">
                    <span class="details-label">Timeline</span>
                    <span class="details-value">${buyer.timeline}</span>
                </div>
            </div>
            
            <div class="details-section">
                <h4>Lead Information</h4>
                <div class="details-group">
                    <span class="details-label">Source</span>
                    <span class="details-value">${buyer.source}</span>
                </div>
                <div class="details-group">
                    <span class="details-label">Status</span>
                    <span class="details-value">
                        <span class="status-badge status-${buyer.status.toLowerCase().replace(/\s+/g, '-')}">${buyer.status}</span>
                    </span>
                </div>
                <div class="details-group">
                    <span class="details-label">Created</span>
                    <span class="details-value">${formatDate(buyer.createdAt)}</span>
                </div>
                <div class="details-group">
                    <span class="details-label">Last Updated</span>
                    <span class="details-value">${formatDate(buyer.updatedAt)}</span>
                </div>
            </div>
            
            <div class="details-section">
                <h4>Additional Information</h4>
                ${buyer.notes ? `
                <div class="details-group">
                    <span class="details-label">Notes</span>
                    <span class="details-value">${buyer.notes}</span>
                </div>
                ` : ''}
                ${buyer.tags && buyer.tags.length > 0 ? `
                <div class="details-group">
                    <span class="details-label">Tags</span>
                    <div class="details-tags">
                        ${buyer.tags.map(tag => `<span class="tag">${tag}</span>`).join('')}
                    </div>
                </div>
                ` : ''}
            </div>
            
            <div class="history-section">
                <h4>Change History</h4>
                <div class="history-timeline">
                    <div class="history-item">
                        <div class="history-icon">📅</div>
                        <div class="history-content">
                            <div class="history-action">Lead Created</div>
                            <div class="history-time">${formatDate(buyer.createdAt)}</div>
                        </div>
                    </div>
                    ${buyer.createdAt !== buyer.updatedAt ? `
                    <div class="history-item">
                        <div class="history-icon">✏️</div>
                        <div class="history-content">
                            <div class="history-action">Lead Updated</div>
                            <div class="history-time">${formatDate(buyer.updatedAt)}</div>
                        </div>
                    </div>
                    ` : ''}
                </div>
            </div>
        </div>
        
        <div class="modal-actions">
            <button class="btn btn--outline" onclick="closeBuyerDetails()">Close</button>
            <button class="btn btn--primary" onclick="editBuyer('${buyer.id}')">Edit Buyer</button>
        </div>
    `;
    
    modal.classList.remove('hidden');
};

window.editBuyer = function(id) {
    const buyer = appState.buyers.find(b => b.id === id);
    if (!buyer) return;
    
    // Close details modal if open
    const detailsModal = document.getElementById('buyerDetailsModal');
    if (detailsModal) {
        detailsModal.classList.add('hidden');
    }
    
    openBuyerModal(buyer);
};

window.deleteBuyer = function(id) {
    const buyer = appState.buyers.find(b => b.id === id);
    if (!buyer) return;
    
    showConfirmDialog(
        'Delete Buyer',
        `Are you sure you want to delete ${buyer.fullName}?`,
        () => {
            appState.buyers = appState.buyers.filter(b => b.id !== id);
            applyFilters();
            showToast('Buyer deleted successfully');
            
            if (appState.currentPage === 'dashboard') {
                updateDashboardStats();
                updateRecentActivity();
            }
        }
    );
};

window.closeBuyerDetails = function() {
    const modal = document.getElementById('buyerDetailsModal');
    if (modal) {
        modal.classList.add('hidden');
    }
};

// Import/Export Functions
function initImportExportPage() {
    const fileInput = document.getElementById('csvFileInput');
    const browseBtn = document.getElementById('browseFileBtn');
    const uploadArea = document.getElementById('fileUploadArea');
    const importBtn = document.getElementById('importBtn');
    const downloadTemplateBtn = document.getElementById('downloadTemplateBtn');
    const exportBtn = document.getElementById('exportDataBtn');
    
    if (browseBtn && fileInput) {
        browseBtn.addEventListener('click', () => fileInput.click());
    }
    
    if (fileInput) {
        fileInput.addEventListener('change', handleFileSelect);
    }
    
    if (importBtn) {
        importBtn.addEventListener('click', handleImport);
    }
    
    if (downloadTemplateBtn) {
        downloadTemplateBtn.addEventListener('click', downloadTemplate);
    }
    
    if (exportBtn) {
        exportBtn.addEventListener('click', exportBuyers);
    }
    
    // Drag and drop
    if (uploadArea) {
        uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadArea.classList.add('dragover');
        });
        
        uploadArea.addEventListener('dragleave', () => {
            uploadArea.classList.remove('dragover');
        });
        
        uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadArea.classList.remove('dragover');
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                handleFile(files[0]);
            }
        });
        
        uploadArea.addEventListener('click', () => {
            if (fileInput) fileInput.click();
        });
    }
}

function handleFileSelect(e) {
    const file = e.target.files[0];
    if (file) {
        handleFile(file);
    }
}

function handleFile(file) {
    if (!file.name.endsWith('.csv')) {
        showToast('Please select a CSV file', 'error');
        return;
    }
    
    const reader = new FileReader();
    reader.onload = (e) => {
        const csv = e.target.result;
        parseCSV(csv);
    };
    reader.readAsText(file);
}

function parseCSV(csv) {
    const lines = csv.split('\n').filter(line => line.trim());
    if (lines.length < 2) {
        showToast('CSV file must contain headers and at least one data row', 'error');
        return;
    }
    
    const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
    const requiredHeaders = ['fullName', 'phone', 'city', 'propertyType', 'purpose', 'timeline', 'source', 'status'];
    
    // Check required headers
    const missingHeaders = requiredHeaders.filter(h => !headers.includes(h));
    if (missingHeaders.length > 0) {
        showToast(`Missing required headers: ${missingHeaders.join(', ')}`, 'error');
        return;
    }
    
    const data = [];
    const errors = [];
    
    for (let i = 1; i < lines.length; i++) {
        const values = lines[i].split(',').map(v => v.trim().replace(/"/g, ''));
        const row = {};
        
        headers.forEach((header, index) => {
            row[header] = values[index] || '';
        });
        
        // Validate row
        const rowErrors = validateImportRow(row, i + 1);
        if (rowErrors.length > 0) {
            errors.push(...rowErrors);
        } else {
            data.push(row);
        }
    }
    
    displayImportPreview(data, errors);
}

function validateImportRow(row, rowNumber) {
    const errors = [];
    
    if (!row.fullName || row.fullName.length < 2 || row.fullName.length > 80) {
        errors.push(`Row ${rowNumber}: Invalid fullName`);
    }
    
    if (!row.phone || !/^[0-9]{10,15}$/.test(row.phone)) {
        errors.push(`Row ${rowNumber}: Invalid phone number`);
    }
    
    if (!config.cities.includes(row.city)) {
        errors.push(`Row ${rowNumber}: Invalid city`);
    }
    
    if (!config.propertyTypes.includes(row.propertyType)) {
        errors.push(`Row ${rowNumber}: Invalid property type`);
    }
    
    if (!config.purposes.includes(row.purpose)) {
        errors.push(`Row ${rowNumber}: Invalid purpose`);
    }
    
    if (!config.timelines.includes(row.timeline)) {
        errors.push(`Row ${rowNumber}: Invalid timeline`);
    }
    
    if (!config.sources.includes(row.source)) {
        errors.push(`Row ${rowNumber}: Invalid source`);
    }
    
    if (!config.statuses.includes(row.status)) {
        errors.push(`Row ${rowNumber}: Invalid status`);
    }
    
    if (row.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(row.email)) {
        errors.push(`Row ${rowNumber}: Invalid email`);
    }
    
    if (['Apartment', 'Villa'].includes(row.propertyType) && !config.bhkOptions.includes(row.bhk)) {
        errors.push(`Row ${rowNumber}: BHK required for ${row.propertyType}`);
    }
    
    return errors;
}

function displayImportPreview(data, errors) {
    const preview = document.getElementById('importPreview');
    const status = document.getElementById('importStatus');
    const tableHead = document.getElementById('previewTableHead');
    const tableBody = document.getElementById('previewTableBody');
    const importBtn = document.getElementById('importBtn');
    
    if (!preview || !status || !tableHead || !tableBody || !importBtn) return;
    
    if (errors.length > 0) {
        status.className = 'import-status error';
        status.innerHTML = `
            <strong>Validation Errors (${errors.length}):</strong>
            <ul>${errors.map(error => `<li>${error}</li>`).join('')}</ul>
        `;
        importBtn.disabled = true;
    } else {
        status.className = 'import-status success';
        status.textContent = `✅ ${data.length} records ready for import`;
        importBtn.disabled = false;
    }
    
    if (data.length > 0) {
        const headers = Object.keys(data[0]);
        tableHead.innerHTML = `<tr>${headers.map(h => `<th>${h}</th>`).join('')}</tr>`;
        tableBody.innerHTML = data.slice(0, 5).map(row => 
            `<tr>${headers.map(h => `<td>${row[h] || ''}</td>`).join('')}</tr>`
        ).join('');
        
        if (data.length > 5) {
            tableBody.innerHTML += `<tr><td colspan="${headers.length}" style="text-align: center; font-style: italic;">... and ${data.length - 5} more rows</td></tr>`;
        }
    }
    
    preview.classList.remove('hidden');
    window.importData = data; // Store for import
}

function handleImport() {
    if (!window.importData || window.importData.length === 0) {
        showToast('No valid data to import', 'error');
        return;
    }
    
    const newBuyers = window.importData.map(row => ({
        id: generateId(),
        fullName: row.fullName,
        email: row.email || '',
        phone: row.phone,
        city: row.city,
        propertyType: row.propertyType,
        bhk: row.bhk || '',
        purpose: row.purpose,
        budgetMin: row.budgetMin ? parseInt(row.budgetMin) : null,
        budgetMax: row.budgetMax ? parseInt(row.budgetMax) : null,
        timeline: row.timeline,
        source: row.source,
        status: row.status,
        notes: row.notes || '',
        tags: row.tags ? row.tags.split(';').map(t => t.trim()) : [],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
    }));
    
    appState.buyers.push(...newBuyers);
    showToast(`Successfully imported ${newBuyers.length} buyers`);
    
    // Reset import
    const fileInput = document.getElementById('csvFileInput');
    const importPreview = document.getElementById('importPreview');
    const importBtn = document.getElementById('importBtn');
    
    if (fileInput) fileInput.value = '';
    if (importPreview) importPreview.classList.add('hidden');
    if (importBtn) importBtn.disabled = true;
    
    window.importData = null;
    
    if (appState.currentPage === 'buyers') {
        applyFilters();
    }
}

function downloadTemplate() {
    const headers = [
        'fullName', 'email', 'phone', 'city', 'propertyType', 'bhk', 
        'purpose', 'budgetMin', 'budgetMax', 'timeline', 'source', 
        'status', 'notes', 'tags'
    ];
    
    const sampleRow = [
        'John Doe', 'john@example.com', '9876543210', 'Mumbai', 'Apartment',
        '2BHK', 'Buy', '5000000', '7000000', '3-6 months', 'Website',
        'New', 'Looking for apartment near office', 'urgent;premium'
    ];
    
    const csv = [headers.join(','), sampleRow.join(',')].join('\n');
    downloadCSV(csv, 'buyer_import_template.csv');
}

function exportBuyers() {
    const exportTypeRadio = document.querySelector('input[name="exportType"]:checked');
    const exportType = exportTypeRadio ? exportTypeRadio.value : 'all';
    const data = exportType === 'filtered' ? appState.filteredBuyers : appState.buyers;
    
    if (data.length === 0) {
        showToast('No data to export', 'error');
        return;
    }
    
    const headers = [
        'fullName', 'email', 'phone', 'city', 'propertyType', 'bhk',
        'purpose', 'budgetMin', 'budgetMax', 'timeline', 'source',
        'status', 'notes', 'tags', 'createdAt', 'updatedAt'
    ];
    
    const csvData = data.map(buyer => 
        headers.map(header => {
            let value = buyer[header];
            if (header === 'tags' && Array.isArray(value)) {
                value = value.join(';');
            }
            return `"${value || ''}"`;
        }).join(',')
    );
    
    const csv = [headers.join(','), ...csvData].join('\n');
    const filename = `buyers_export_${new Date().toISOString().split('T')[0]}.csv`;
    downloadCSV(csv, filename);
    
    showToast(`Exported ${data.length} buyers successfully`);
}

function downloadCSV(csv, filename) {
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
}

// Settings Functions
function initSettingsPage() {
    const recordsPerPageSelect = document.getElementById('recordsPerPage');
    if (!recordsPerPageSelect) return;
    
    recordsPerPageSelect.value = appState.pagination.itemsPerPage;
    
    recordsPerPageSelect.addEventListener('change', (e) => {
        appState.pagination.itemsPerPage = parseInt(e.target.value);
        appState.pagination.currentPage = 1;
        if (appState.currentPage === 'buyers') {
            renderBuyersTable();
            updatePagination();
        }
        showToast('Settings updated');
    });
}

// Modal Management
function initModals() {
    // Close modals with Escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            document.querySelectorAll('.modal:not(.hidden)').forEach(modal => {
                modal.classList.add('hidden');
            });
        }
    });
    
    // Close modal buttons
    const closeBuyerDetailsBtn = document.getElementById('closeBuyerDetails');
    const closeConfirmBtn = document.getElementById('closeConfirm');
    const cancelConfirmBtn = document.getElementById('cancelConfirm');
    const toastCloseBtn = document.getElementById('toastClose');
    
    if (closeBuyerDetailsBtn) {
        closeBuyerDetailsBtn.addEventListener('click', window.closeBuyerDetails);
    }
    
    if (closeConfirmBtn) {
        closeConfirmBtn.addEventListener('click', () => {
            const modal = document.getElementById('confirmModal');
            if (modal) modal.classList.add('hidden');
        });
    }
    
    if (cancelConfirmBtn) {
        cancelConfirmBtn.addEventListener('click', () => {
            const modal = document.getElementById('confirmModal');
            if (modal) modal.classList.add('hidden');
        });
    }
    
    // Toast close button
    if (toastCloseBtn) {
        toastCloseBtn.addEventListener('click', () => {
            const toast = document.getElementById('toast');
            if (toast) toast.classList.add('hidden');
        });
    }
}

// Application Initialization
function init() {
    // Initialize data
    appState.buyers = [...sampleBuyers];
    appState.filteredBuyers = [...appState.buyers];
    appState.pagination.totalItems = appState.buyers.length;
    
    // Initialize components
    initModals();
    
    // Initialize authentication
    const loginForm = document.getElementById('loginForm');
    const demoLoginBtn = document.getElementById('demoLogin');
    const logoutBtn = document.getElementById('logoutBtn');
    
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
    
    if (demoLoginBtn) {
        demoLoginBtn.addEventListener('click', handleDemoLogin);
    }
    
    if (logoutBtn) {
        logoutBtn.addEventListener('click', handleLogout);
    }
}

function initApp() {
    initNavigation();
    initBuyerModal();
    navigateToPage('dashboard');
}

// Start the application
document.addEventListener('DOMContentLoaded', init);